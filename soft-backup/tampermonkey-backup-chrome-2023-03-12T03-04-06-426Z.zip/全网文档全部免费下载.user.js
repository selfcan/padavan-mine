// ==UserScript==
// @name         全网文档全部免费下载
// @namespace    100
// @version      1.8
// @description  道客巴巴豆丁网原创力文档等文档下载文献下载英文文献下载，高清PDF定制。详细使用使用说明：https://www.yuque.com/pdf888/888/rrrcu5
// @AuThor       100

// @include		 *quannen*
 
// @require      https://cdn.staticfile.org/jquery/3.4.1/jquery.min.js
// @require      https://cdn.bootcss.com/jqueryui/1.12.1/jquery-ui.min.js
// @grant GM_setValue
// @grant GM_getValue
// @grant GM_deleteValue
// @grant unsafeWindow
// @grant GM_setClipboard
// @grant window.close
// @grant window.focus
// @grant GM_openInTab
// ==/UserScript==
(function () {
    'use strict';
 
    const ZHIHU_URL = 'https://www.yuque.com/pdf888/888/rrrcu5'
 
    function addButton() {
        $('body').append('<div id="copyToCS"></div>')
        $('#copyToCS').css('width', '260px')
        $('#copyToCS').css('display', 'block')
        $('#copyToCS').css('position', 'absolute')
        $('#copyToCS').css('top', '200px')
        $('#copyToCS').css('right', '0px')
        $('#copyToCS').css('background-color', '#000000')
        $('#copyToCS').css('color', 'white')
        $('#copyToCS').css('font-size', '60px')
		$('#copyToCS').css('font-weight', '900')
        $('#copyToCS').css('z-index', 9999)
        $('#copyToCS').css('border-radius', '15px')
        $('#copyToCS').css('text-align', 'center')
		$('#copyToCS').css('cursor', 'pointer')
        $('#copyToCS').click(function () {
            GM_openInTab(ZHIHU_URL, true)
        })
        $('#copyToCS').draggable()
    }
   addButton()
})()