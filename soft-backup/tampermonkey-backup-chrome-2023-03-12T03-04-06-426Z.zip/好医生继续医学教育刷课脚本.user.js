// ==UserScript==
// @name         好医生继续医学教育刷课脚本
// @version      0.2
// @description  好医生
// @author       堂吉诃德
// @include        *://www.cmechina.net/*
// @grant        none
// @namespace https://greasyfork.org/users/168620
// ==/UserScript==

(function() {
'use strict';
var inte = setInterval(() => {
    if (window.cc_js_Player) {
      clearInterval(inte);
      window.cc_js_Player.params.autoStart = true;
    }
  }, 50);

  var hre = location.href;
  var isVideopage;
  var que;
  isVideopage = hre.indexOf("www.cmechina.net/cme/study2.jsp?course_id") != -1;
  if (isVideopage) {
    setInterval(() => {
      que = document.querySelector('.cur').href
      if (que && que != '#') {
        if (document.querySelector('li.active[id] + li')) {
          document.querySelector('li.active[id] + li > a').click();
        }
      }
    }, 30 * 1000);
  }
})();