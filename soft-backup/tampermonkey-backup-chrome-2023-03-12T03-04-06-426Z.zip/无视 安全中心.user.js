// ==UserScript==
// @name 无视 安全中心
// @description 自动打开 腾讯 && 知乎 && 贴吧 && 简书 && 百度 && csdn 的不让人打开的网址
// @version 2.0
// @author 江小白
// @match *://c.pc.qq.com/*.html?pfurl=*
// @match *://docs.qq.com/scenario/link.html?url=*
// @match *://link.zhihu.com/?target=http*
// @match *://link.csdn.net/?target=http*
// @match *://bsb.baidu.com/lanjie/*.html?http*
// @match *://mail.qq.com/cgi-bin/readtemplate?t=safety&check=false&gourl=http*
// @include /^https?:\/\/jump\d?\.bdimg\.com\/safecheck\/index\?url=/
// @include /^https?:\/\/www\.jianshu\.com\/go-wild\?ac=\d+?&url=http/
// @grant none
// @noframes
// @run-at document-body
// @namespace https://greasyfork.org/users/694396
// ==/UserScript==


(function() {
	'use strict';
	try {
		if (self != top) {
			return false;
		} else {
			let w = location.href;
			if (w.match(/^https?:\/\/(?:c\.pc\.qq\.com\/\w+?\.html\?pfurl=|[^\/]+?\/\?target=|docs\.qq\.com\/scenario\/link\.html\?url=|www\.jianshu\.com\/go-wild\?ac=\d+?&url=http|mail\.qq\.com\/cgi-bin\/readtemplate\?t=safety&check=false&gourl=http)/)) {
				window.location.href = unescape(window.location).replace(/^.+?\?pfurl=(.+?)&pfuin=.*$/, "$1").replace(/^.+?\?target=(http.+)$/, "$1").replace(/^.+?\.html\?url=(https.+?)&[cp]id=.+$/, "$1").replace(/^.+?\/go-wild\?ac=\d+?&url=(http.+)$/, "$1").replace(/^.+?&gourl=(http.+?)&subtemplate=.*$/, "$1");
			} else if (w.match(/^https?:\/\/jump\d?\.bdimg\.com\/safecheck\/index\?url=/)) {
				if (document.querySelector('div.warning_info.fl>a[href^="http"]').innerText === '继续访问') {
					window.top.location.replace(document.querySelector('div.warning_info.fl>a[href^="http"]').href);
				} else {}
			} else if (w.match(/^https?:\/\/bsb\.baidu\.com\/lanjie\/\w+?\.html\?http/)) {
				if (document.querySelector('div[class^="operations"]>a:last-of-type').innerText === '继续访问（不推荐）') {
					window.top.location.replace(document.querySelector('div[class^="operations"]>a:last-of-type').href);
				} else {}
			} else {}
		}
	} catch (err) {
		return false;
	}
})();