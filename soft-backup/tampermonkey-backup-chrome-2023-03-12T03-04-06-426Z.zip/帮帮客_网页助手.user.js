// ==UserScript==
// @name         帮帮客_网页助手
// @namespace    http://tampermonkey.net/
// @version      3.2
// @description  【新·简报】 『华医网 => 公需课、选修课、学分类』QQ用户群：904423745；
// @author       帮帮客
// @license      bbk_1106

// @match        *://*.91huayi.com/*
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_listValues
// @grant        GM_xmlhttpRequest
// @grant        unsafeWindow
// @icon         https://mmbiz.qpic.cn/mmbiz_jpg/nc15h3nWHMVYP16HAuFe6PNJcic7mB6GFnNmk61LSHfH9ZPUoOWKnZiaaB9Jze8hCyrEYzIyicOzibs3e6ZIJTlcgw/640?wx_fmt=jpeg
// @run-at       document-start
// ==/UserScript==
class Verify {
    constructor() {
        var version = 'version',hear = 'hear',version_ = "3.2";
        var txt,str;
        txt = '操作流程：\n' +
            '1.复制输入框里的内容；\n' +
            '2.点击浏览器右上角的油猴图标；\n' +
            '3.点击管理面板，找到刚安装的油猴脚本并点击打开；\n' +
            '4.在下方这行代码下，有一行是空白行，请将复制的内容粘贴上去；\n' +
            '[ // @require      https://cdn*****jquery.js]\n' +
            '[                             空白行                          ]\n' + //！！！！注意：并非替换此行，请将复制的内容粘贴到【第8行】！（鼠标滚轮往上滑，在上方）
            '[ // @grant         GM_setValue                  ]\n' +
            '5.保存后刷新华医网。 < Ctrl + C 复制下方输入框内容>';
        str = '// @require      http://139.224.47.209:91/bbk_zs_3.2.js';
        let Set = GM_getValue("set");
        if (GM_listValues().indexOf("set") == -1) {
            GM_setValue("set", {
                "idCard": "",
                "code": "",
                "hear": "",
                "version": ""
            });
            confirm("华医网_JavaScript\n初始化完毕!\n请按流程完成功能激活。");
        }
        setTimeout(function () {
            Set = GM_getValue("set");
            if (Set[hear] != true) {
                data();
                let url_n = unsafeWindow.location.href.split("/");
                if (url_n[3] != 'rawsystem') {
                    prompt(txt, str);
                }
            } else if (Set[hear] == true && Set[version] != version_) {
                data();
                prompt('华医网_JavaScript\n提示：您有新版本更新\n当前版本:' + Set[version] + ' 最新版本:' + version_ + '\n' +
                    '请将输入框内容复制粘贴到代码【空白行】\n' +
                    '[ // @require      https://cdn*****jquery.js]\n' +
                    '[                             空白行                          ]\n' + //！！！！注意：并非替换此行，请将复制的内容粘贴到【第8行】！（鼠标滚轮往上滑，在上方）
                    '[ // @grant                           GM_setValue]\n' +
                    '如需帮助请关注公众号查看说明详情。', str);
            }
            if (document.querySelector('#floatTips2')) {
                document.querySelector('#imga3').style.display = 'none';
                if (document.querySelector('#floatTips')) {
                    document.querySelector('#floatTips').style.display = 'none';
                }
            }
        }, 1500);
        function data() {
            var url_n, url_t;
            url_n = unsafeWindow.location.href.split("/");
            url_t = url_n[url_n.length - 1].split("?")[0];
            if (url_t != "course_list_v2.aspx") {
                $('body').append(`
                    <div id=gzh style="font-weight: bold;right: 17px;font-size: 14px;height: 32px;text-align: center;display: block;background: #ffffff;position: fixed;top: 272px;width: 129px;color: #717375;margin-left: 0px;line-height: 15px;">
                        微信扫一扫
                        <br>
                        关注帮帮客公众号
                    </div>
                    <iframe src="https://mp.weixin.qq.com/mp/qrcode?scene=10000004&size=102&__biz=Mzk0MjMxNTcxOQ==&mid=2247483681&idx=1&sn=382747485cbe09c94f7e7ee0eef363b5&send_time="
                    style="right: 17px;display: block;position: fixed; top:143px;width: 129px;color: #555;margin-left: 0px;line-height: 11px;border-radius: 6px;height: 160px;">
                    </iframe>
                    `);
            }
        }
    }
}
new Verify();