// ==UserScript==
// @name         绕过限制搜索查看百度网盘资源
// @version      4.0
// @namespace    1skiwen
// @description  解决需要关注公众号或注册收费问题，绕过限制直接跳转百度网盘，包括大力盘/罗马盘/大圣盘/小白盘/猪猪盘/小昭来了/小可搜搜
// @author       1skiwen
// @match        http*://www.dalipan.com/*
// @match        http*://www.luomapan.com/*
// @match        http*://www.dashengpan.com/*
// @match        *://www.xiaokesoso.com/*
// @match        *://www.xiaozhaolaila.com/*
// @match        http://www.zhuzhupan.com/search*
// @match        https://www.xiaobaipan.com/file*
// @require      https://cdn.staticfile.org/jquery/3.3.1/jquery.min.js
// @run-at document-end
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var host = location.host
    var isDomain = function (t) {
        return host.indexOf(t) !== -1
    }

    $("head").append (
        '<link '
        + 'href="https://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.min.css" '
        + 'rel="stylesheet" type="text/css">'
    );

    var para = document.createElement("div");
    para.innerHTML = '<div style="position:fixed;left:50px;top:220px;display:flex;border-radius:50%;" id="download"><a style="font-size:5em;text-align:center;" href="" target="_blank"><i class="fa fa-arrow-circle-down"></i></a></div>';


    if ((isDomain('dalipan')) || (isDomain('dashengpan')) || (isDomain('luomapan'))) {
        if (document.location.href.includes("search?keyword=")) {
            document.querySelectorAll('.resource-title a').forEach((element, index) => {
                if (element.href.includes("javascript")) {
                    element.href="/detail/" + __NUXT__.data[0].results[index].res.id
                }
            })
        }
        if(document.location.href.includes("detail")){
            var url = window.__NUXT__.data[0].url
            if(window.__NUXT__.data[0].haspwd) url += '#' + window.__NUXT__.data[0].pwd

            document.body.appendChild(para);
            document.querySelector("#download a").href = url;
        }
    }

    else if ((isDomain('xiaokesoso')) || isDomain('xiaozhaolaila')) {
        const ele = document.querySelector('button[data-downloadurl]');
        if(ele){
            const jumpUrl = "http://norefer.mimixiaoke.com/api/jump?target=" + ele.dataset.downloadurl;
            document.body.appendChild(para);
            document.querySelector("#download a").href = jumpUrl;
        }
    }
    else if(isDomain('zhuzhupan')){
        const query=window.location.href.match(/query=(\S*?)&/)[1];
        //console.log(s==1)
        if(query && document.querySelector("a[onclick^='showPay']")){
            console.log('jump');
            window.location.href='http://www.zhuzhupan.com/paysuccess?id='+query +'||_||&_t='+Date.parse(new Date())
        }
    }
    else if(isDomain('xiaobaipan')){
        let baipan_url = $("#rel-url a").attr("href");
        document.body.appendChild(para);
        document.querySelector("#download a").href = baipan_url;

    }

})();