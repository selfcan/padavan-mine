// ==UserScript==
// @name         jiumo鸠摩搜书免关注
// @namespace    http://tampermonkey.net/
// @version      0.5
// @description  去除鸠摩搜书的关注公众号弹窗
// @author       You
// @match        *://www.jiumodiary.com/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    document.addEventListener('DOMNodeInserted', e => {
        [...e.target.querySelectorAll('a')].map(ele => {
            ele.onclick = null
            ele.href = ele.getAttribute('data-href') || ele.href
            ele.target = '_blank'
        })
    });

})();