// ==UserScript==
// @name        📝文本选中复制|VIP文档免费下载|VIP文库下载器
// @namespace   http://github.com/suifeng/yixing
// @version     6.3.3
// @author      xxkil
// @contributionURL https://pic4.zhimg.com/80/v2-b331d70d7350c887d39a8fd78a85de3f_720w.jpg
// @description  👍👍👍文库下载器|VIP文档免费下载|✅绝大部分网站选中右键自动复制✅|傻瓜式全文粘贴🍭🍭🍭此脚本解除①百度文库、②道客巴巴、③知乎、④无忧考网、⑤学习啦、⑥新浪文档等常见网站不允许复制的限制🍆🍆🍆选中要复制的段落后，会自动出现复制按钮📈📈📈，点击复制按钮即可复制。新增JD购物优惠券查询功能。😎😎😎
// @include  https://www.hihonor.com/*
// @include  https://www.ymatou.hk/*
// @include  https://www.ymatou.com/*
// @antifeature referral-link 内部隐藏优惠卷
// @include  https://traveldetail.fliggy.com/*
// @include  https://traveldetail.fliggy.com/*
// @include  http://*.wzhouhui.com/*
// @include  https://*.wzhouhui.com/*
// @include  http://cn.wemakepricea.com/*
// @include  https://cn.wemakeprice.com/*
// @include  https://cn.dod.nl/*
// @include  http://*.decathlon.com.cn/*
// @include  https://*.decathlon.com.cn/*
// @include  http://cn.apo.com/*
// @include  http://*.ansgo.com/*
// @include  https://*.ansgo.com/*
// @include  https://*.perfumesclub.cn/*
// @include  http://*.net-a-porter.com/*
// @include  https://*.net-a-porter.com/*
// @include  http://*.kidsroom.cn/*
// @include  https://*.kidsroom.cn/*
// @include  http://cn.getthelabel.com/*
// @include  http://*.farfetch.cn/*
// @include  https://*.farfetch.cn/*
// @include  http://item.kongfz.com/*
// @include  https://item.kongfz.com/*
// @include  http://book.kongfz.com/*
// @include  https://book.kongfz.com/*
// @include  http://cn.iherb.com/*
// @include  https://cn.iherb.com/*
// @include  http://*.hqhair.com/*
// @include  https://*.hqhair.com/*
// @include  http://*.wl.cn/*
// @include  https://*.wl.cn/*
// @include  http://*.columbia.com/*
// @include  https://*.columbia.com/*
// @include  http://*.columbiasports.cn/*
// @include  https://*.columbiasports.cn/*
// @include  http://*.ehaoyao.com/*
// @include  https://*.ehaoyao.com/*
// @include  http://*.bhphotovideo.com/*
// @include  https://*.bhphotovideo.com/*
// @include  http://*.shoes.com/*
// @include  https://*.shoes.com/*
// @include  http://*.jomashop.com/*
// @include  https://*.jomashop.com/*
// @include  http://cn.pharmacydirect.co.nz/*
// @include  https://cn.pharmacydirect.co.nz/*
// @include  http://*.holland-at-home.com/*
// @include  https://*.holland-at-home.com/*
// @include  http://cn.holland-at-home.com/*
// @include  https://cn.holland-at-home.com/*
// @include  http://*.rei.com/*
// @include  https://*.rei.com/*
// @include  http://item.aomygod.com/*
// @include  https://item.aomygod.com/*
// @include  http://*.huatuoyf.com/*
// @include  https://*.huatuoyf.com/*
// @include  http://*.forever21.com/*
// @include  https://*.forever21.com/*
// @include  http://zh.ashford.com/*
// @include  https://zh.ashford.com/*
// @include  http://*.bestbuy.com/*
// @include  https://*.bestbuy.com/*
// @include  http://*.target.com/*
// @include  https://*.target.com/*
// @include  http://cn.chemistdirect.com.au/*
// @include  https://cn.chemistdirect.com.au/*
// @include  http://*.ba.de/*
// @include  https://*.ba.de/*
// @include  http://m.wandougongzhu.cn/*
// @include  https://m.wandougongzhu.cn/*
// @include  http://cn.feelunique.com/*
// @include  https://cn.feelunique.com/*
// @include  http://shop.dixintong.com/*
// @include  https://shop.dixintong.com/*
// @include  http://cn.pharmacyonline.com.au/*
// @include  https://cn.pharmacyonline.com.au/*
// @include  http://cn.discount-apotheke.de/*
// @include  https://cn.discount-apotheke.de/*
// @include  http://*.carters.com/*
// @include  http://*.katespade.co.uk/*
// @include  https://*.katespade.co.uk/*
// @include  http://*.katespade.cn/*
// @include  https://*.katespade.cn/*
// @include  http://*.beautybay.com/*
// @include  https://*.beautybay.com/*
// @include  http://cn.pharmacy4less.com.au/*
// @include  https://cn.pharmacy4less.com.au/*
// @include  http://*.newegg.com/*
// @include  https://*.newegg.com/*
// @include  http://*.newbalance.com/*
// @include  https://*.newbalance.com/*
// @include  http://*.bodybuilding.com/*
// @include  https://*.bodybuilding.com/*
// @include  http://*.ssnewyork.com/*
// @include  https://*.ssnewyork.com/*
// @include  http://*.wine9.com/*
// @include  https://*.wine9.com/*
// @include  http://*.kohls.com/*
// @include  https://*.kohls.com/*
// @include  http://*.gnc.com/*
// @include  https://*.gnc.com/*
// @include  http://*.qw.cc/*
// @include  https://*.qw.cc/*
// @include  http://*.haiershui.com/*
// @include  https://*.haiershui.com/*
// @include  http://*.ugg.com/*
// @include  http://*.ugg.com/*
// @include  http://*.ugg.cn/*
// @include  https://*.ugg.cn/*
// @include  http://*.yoger.com.cn/*
// @include  https://*.yoger.com.cn/*
// @include  http://*.flyco.com/*
// @include  https://*.flyco.com/*
// @include  http://*.yfdyf.com/*
// @include  https://*.yfdyf.com/*
// @include  http://*.joesnewbalanceoutlet.com/*
// @include  https://*.joesnewbalanceoutlet.com/*
// @include  http://*.jomoo.com.cn/*
// @include  https://*.jomoo.com.cn/*
// @include  http://*.dapu.com/*
// @include  https://*.dapu.com/*
// @include  http://china.coach.com/*
// @include  https://china.coach.com/*
// @include  http://*.shanmai.cn/*
// @include  https://*.shanmai.cn/*
// @include  http://*.fengbuy.com/*
// @include  https://*.fengbuy.com/*
// @include  http://*.t10.com/*
// @include  https://*.t10.com/*
// @include  http://cn.amcal.com.au/*
// @include  https://cn.amcal.com.au/*
// @include  http://cn.babyhaven.com/*
// @include  https://cn.babyhaven.com/*
// @include  http://*.51taouk.com/*
// @include  https://*.51taouk.com/*
// @include  http://*.usashopcn.com/*
// @include  https://*.usashopcn.com/*
// @include  http://*.petit-bateau.us/*
// @include  https://*.petit-bateau.us/*
// @include  http://*.tlcpharmacy.cn.com/*
// @include  https://*.tlcpharmacy.cn.com/*
// @include  http://*.km1818.com/*
// @include  https://*.km1818.com/*
// @include  http://*.bienmanger.cn/*
// @include  https://*.bienmanger.cn/*
// @include  http://*.syshop.com/*
// @include  https://*.syshop.com/*
// @include  http://*.qipaimall.com/*
// @include  https://*.qipaimall.com/*
// @include  http://mall.goumin.com/*
// @include  https://mall.goumin.com/*
// @include  http://*.taohwu.com/*
// @include  https://*.taohwu.com/*
// @include  http://*.xmeise.com/*
// @include  https://*.xmeise.com/*
// @include  http://*.septwolves.cn/*
// @include  https://*.septwolves.cn/*
// @include  http://*.kiehls.com/*
// @include  https://*.kiehls.com/*
// @include  http://*.puzeyf.com/*
// @include  https://*.puzeyf.com/*
// @include  http://*.aizhigu.com.cn/*
// @include  https://*.aizhigu.com.cn/*
// @include  http://*.hecha.cn/*
// @include  https://*.hecha.cn/*
// @include  http://*.zgshoes.com/*
// @include  https://*.zgshoes.com/*
// @include  http://cn.takeya.co.jp/*
// @include  https://cn.takeya.co.jp/*
// @include  http://*.shoprobam.com/*
// @include  https://*.shoprobam.com/*
// @include  http://*.opplestore.com/*
// @include  https://*.opplestore.com/*
// @include  http://*.maichawang.com/*
// @include  https://*.maichawang.com/*
// @include  http://*.bose.com/*
// @include  https://*.bose.com/*
// @include  http://dewaren.com/*
// @include  https://dewaren.com/*
// @include  http://*.winona.cn/*
// @include  https://*.winona.cn/*
// @include  http://*.motorola.com.cn/*
// @include  https://*.motorola.com.cn/*
// @include  http://*.danielwellington.cn/*
// @include  https://*.danielwellington.cn/*
// @include  http://*.danielwellington.com/*
// @include  https://*.danielwellington.com/*
// @include  http://youhui.pinduoduo.com/*
// @include  https://youhui.pinduoduo.com/*
// @include  http://*.yangkeduo.com/*
// @include  https://*.yangkeduo.com/*
// @include  http://*.finishline.com/*
// @include  https://*.finishline.com/*
// @include  http://*.skinstore.com/*
// @include  https://*.skinstore.com/*
// @include  http://item.wjike.com/*
// @include  https://item.wjike.com/*
// @include  http://youpin.mi.com/*
// @include  https://youpin.mi.com/*
// @include  http://*.xiaomiyoupin.com/*
// @include  https://*.xiaomiyoupin.com/*
// @include  http://store.steampowered.com/*
// @include  https://store.steampowered.com/*
// @include  http://*.jialich.cn/*
// @include  https://*.jialich.cn/*
// @include  http://*.tthigo.com/*
// @include  https://*.tthigo.com/*
// @include  http://*.modernavenue.com/*
// @include  https://*.modernavenue.com/*
// @include  http://*.tcl.com/*
// @include  https://*.tcl.com/*
// @include  http://*.bonjourhk.com/*
// @include  https://*.bonjourhk.com/*
// @include  http://m.bonjourhk.com/*
// @include  https://m.bonjourhk.com/*
// @include  http://*.trt.hk/*
// @include  https://*.trt.hk/*
// @include  http://*.forestfood.com/*
// @include  https://*.forestfood.com/*
// @include  http://*.converse.com.cn/*
// @include  https://*.converse.com.cn/*
// @include  http://*.fila.cn/*
// @include  https://*.fila.cn/*
// @include  http://*.levi.com.cn/*
// @include  https://*.levi.com.cn/*
// @include  http://*.levi.com/*
// @include  https://*.levi.com/*
// @include  http://*.hangowa.com/*
// @include  https://*.hangowa.com/*
// @include  http://*.super-in.com/*
// @include  https://*.super-in.com/*
// @include  http://*.ccxpet.com/*
// @include  https://*.ccxpet.com/*
// @include  http://*.360lj.com/*
// @include  https://*.360lj.com/*
// @include  http://*.hysjg.com/*
// @include  https://*.hysjg.com/*
// @include  http://*.0061.com.au/*
// @include  https://*.0061.com.au/*
// @include  http://mall.ecovacs.cn/*
// @include  https://mall.ecovacs.cn/*
// @include  http://mall.littleswan.com/*
// @include  https://mall.littleswan.com/*
// @include  https://*.vitagou.hk/*
// @include  https://*.vitagou.hk/*
// @include  http://*.hpstore.cn/*
// @include  https://*.hpstore.cn/*
// @include  http://*.kkguan.com/*
// @include  https://*.kkguan.com/*
// @include  http://*.mayn.com.cn/*
// @include  https://*.mayn.com.cn/*
// @include  http://*.peikua.com/*
// @include  https://*.peikua.com/*
// @include  http://item.kinhom.com/*
// @include  https://item.kinhom.com/*
// @include  http://*.9drug.com/*
// @include  https://*.9drug.com/*
// @include  http://*.tea7.com/*
// @include  https://*.tea7.com/*
// @include  http://*.01home.com/*
// @include  https://*.01home.com/*
// @include  http://*.aliexpress.com/*
// @include  https://*.aliexpress.com/*
// @include  http://*.easytoys.cn/*
// @include  https://*.easytoys.cn/*
// @include  http://*.kiwistarcare.com/*
// @include  https://*.kiwistarcare.com/*
// @include  http://*.carrefour.cn/*
// @include  https://*.carrefour.cn/*
// @include  http://china.lotte.com/*
// @include  https://china.lotte.com/*
// @include  http://*.ewatches.com/*
// @include  https://*.ewatches.com/*
// @include  http://global.timex.com/*
// @include  https://global.timex.com/*
// @include  http://comfortfirst.com/*
// @include  https://comfortfirst.com/*
// @include  http://*.luolai.cn/*
// @include  https://*.luolai.cn/*
// @include  http://*.youyu.com/*
// @include  https://*.youyu.com/*
// @include  http://*.yoox.cn/*
// @include  https://*.yoox.cn/*
// @include  http://store.yoox.cn/*
// @include  https://store.yoox.cn/*
// @include  http://*.suanjuzi.com/*
// @include  https://*.suanjuzi.com/*
// @include  http://*.yao123.com/*
// @include  https://*.yao123.com/*
// @include  http://item.baobeigezi.com/*
// @include  https://item.baobeigezi.com/*
// @include  http://*.baobeigezi.com/*
// @include  https://*.baobeigezi.com/*
// @include  http://*.opposhop.cn/*
// @include  https://*.opposhop.cn/*
// @include  http://store.oppo.com/*
// @include  https://store.oppo.com/*
// @include  http://*.oppo.com/*
// @include  https://*.oppo.com/*
// @include  http://hd.oppo.com/*
// @include  https://hd.oppo.com/*
// @include  http://mall.to8to.com/*
// @include  https://mall.to8to.com/*
// @include  http://item.yunhou.com/*
// @include  https://item.yunhou.com/*
// @include  http://item.yhd.com/*
// @include  https://item.yhd.com/*
// @include  http://*.haituncun.com/*
// @include  https://*.haituncun.com/*
// @include  http://*.walmart.com/*
// @include  https://*.walmart.com/*
// @include  http://*.vmei.com/*
// @include  https://*.vmei.com/*
// @include  http://*.jgb.cn/*
// @include  https://*.jgb.cn/*
// @include  http://*.51din.com/*
// @include  https://*.51din.com/*
// @include  http://*.aidai.com/*
// @include  https://*.aidai.com/*
// @include  http://shop.boqii.com/*
// @include  https://shop.boqii.com/*
// @include  http://*.spider.com.cn/*
// @include  https://*.spider.com.cn/*
// @include  http://*.jiae.com/*
// @include  https://*.jiae.com/*
// @include  http://*.zazhipu.com/*
// @include  https://*.zazhipu.com/*
// @include  http://*.shop.philips.com.cn/*
// @include  https://*.shop.philips.com.cn/*
// @include  http://tuan.zhongjiu.cn/*
// @include  https://tuan.zhongjiu.cn/*
// @include  http://*.zhongjiu.cn/*
// @include  https://*.zhongjiu.cn/*
// @include  http://*.kaluli.com/*
// @include  https://*.kaluli.com/*
// @include  http://shop.wstx.com/*
// @include  https://shop.wstx.com/*
// @include  http://*.purcotton.com/*
// @include  https://*.purcotton.com/*
// @include  http://shop.juanpi.com/*
// @include  https://shop.juanpi.com/*
// @include  http://*.jinxiang.com/*
// @include  https://*.jinxiang.com/*
// @include  http://*.163.com/*
// @include  https://*.163.com/*
// @include  http://*.guojimami.com/*
// @include  https://*.guojimami.com/*
// @include  http://*.baiyangwang.com/*
// @include  https://*.baiyangwang.com/*
// @include  http://cn.royyoungchemist.com.au/*
// @include  https://cn.royyoungchemist.com.au/*
// @include  http://cn.medihealshop.com/*
// @include  https://cn.medihealshop.com/*
// @include  http://*.medihealshop.com/*
// @include  https://*.medihealshop.com/*
// @include  http://cn.1001pharmacies.com/*
// @include  https://cn.1001pharmacies.com/*
// @include  http://*.lookfantastic.cn/*
// @include  https://*.lookfantastic.cn/*
// @include  http://*.lookfantastic.com/*
// @include  https://*.lookfantastic.com/*
// @include  http://you.163.com/*
// @include  https://you.163.com/*
// @include  http://product.bl.com/*
// @include  https://product.bl.com/*
// @include  http://*.bestinfoods.com/*
// @include  https://*.bestinfoods.com/*
// @include  http://*.muji.net/*
// @include  https://*.mujli.net/*
// @include  http://*.easeeyes.com/*
// @include  https://*.easeeyes.com/*
// @include  http://*.lingshi.com/*
// @include  https://*.lingshi.com/*
// @include  http://*.nubia.com/*
// @include  https://*.nubia.com/*
// @include  http://shop.nubia.com/*
// @include  https://shop.nubia.com/*
// @include  http://*.nubia.cn/*
// @include  https://*.nubia.cn/*
// @include  http://*.kzj365.com/*
// @include  https://*.kzj365.com/*
// @include  http://*.kaola.com/*
// @include  https://*.kaola.com/*
// @include  http://*.kaola.com.hk/*
// @include  https://*.kaola.com.hk/*
// @include  http://*.kaola.com.hk/*
// @include  https://*.kaola.com.hk/*
// @include  http://*.ymatou.com/*
// @include  https://*.ymatou.com/*
// @include  http://detail.metao.com/*
// @include  https://detail.metao.com/*
// @include  http://*.coocaa.com/*
// @include  https://*.coocaa.com/*
// @include  http://*.lifevc.com/*
// @include  https://*.lifevc.com/*
// @include  http://*.supuy.com/*
// @include  https://*.supuy.com/*
// @include  http://*.supumall.com/*
// @include  https://*.supumall.com/*
// @include  http://*.mia.com/*
// @include  https://*.mia.com/*
// @include  http://miyabaobei.hk/*
// @include  https://miyabaobei.hk/*
// @include  http://*.miyabaobei.hk/*
// @include  https://*.miyabaobei.hk/*
// @include  http://item.gomehigo.hk/*
// @include  https://item.gomehigo.hk/*
// @include  http://*.wangfujing.com/*
// @include  https://*.wangfujing.com/*
// @include  http://global.gou.com/*
// @include  https://global.gou.com/*
// @include  http://*.gou.com/*
// @include  https://*.gou.com/*
// @include  http://*.ikjtao.com/*
// @include  https://*.ikjtao.com/*
// @include  http://*.bestkeep.cn/*
// @include  https://*.bestkeep.cn/*
// @include  http://*.ule.com/*
// @include  https://*.ule.com/*
// @include  http://shop.philips.com.cn/*
// @include  https://shop.philips.com.cn/*
// @include  http://shop.tcl.com/*
// @include  https://shop.tcl.com/*
// @include  http://mall.tcl.com/*
// @include  https://mall.tcl.com/*
// @include  http://*.e-changhong.com/*
// @include  https://*.e-changhong.com/*
// @include  http://shop.konka.com/*
// @include  https://shop.konka.com/*
// @include  http://shop.hisense.com/*
// @include  https://shop.hisense.com/*
// @include  http://*.hisense.com/*
// @include  https://*.hisense.com/*
// @include  http://*.ineigo.com/*
// @include  https://*.ineigo.com/*
// @include  http://*.skg.com/*
// @include  https://*.skg.com/*
// @include  http://*.oyeah.com/*
// @include  https://*.oyeah.com/*
// @include  http://*.morefood.com/*
// @include  https://*.morefood.com/*
// @include  http://*.zhen.com/*
// @include  https://*.zhen.com/*
// @include  http://shop.vivo.com.cn/*
// @include  https://shop.vivo.com.cn/*
// @include  http://gfive.b2c.eqimingxing.com/*
// @include  https://gfive.b2c.eqimingxing.com/*
// @include  http://*.6pm.com/*
// @include  https://*.6pm.com/*
// @include  http://shop.gionee.com/*
// @include  https://shop.gionee.com/*
// @include  http://z.gionee.com/*
// @include  https://z.gionee.com/*
// @include  http://store.lining.com/*
// @include  https://store.lining.com/*
// @include  http://*.mf910.com/*
// @include  https://*.mf910.com/*
// @include  http://*.k-touch.cn/*
// @include  https://*.k-touch.cn/*
// @include  http://item.grainger.cn/*
// @include  https://item.grainger.cn/*
// @include  http://piao.163.com/*
// @include  https://piao.163.com/*
// @include  http://mall.163.com/*
// @include  https://mall.163.com/*
// @include  http://detail.yao.95095.com/*
// @include  https://detail.yao.95095.com/*
// @include  http://*.ebay.com/*
// @include  https://*.ebay.com/*
// @include  http://*.100yue.com/*
// @include  https://*.100yue.com/*
// @include  http://*.feiniu.com/*
// @include  https://*.feiniu.com/*
// @include  http://*.lemall.com/*
// @include  https://*.lemall.com/*
// @include  http://item.feiniu.com/*
// @include  https://item.feiniu.com/*
// @include  http://*.xgbaby.com/*
// @include  https://*.xgbaby.com/*
// @include  http://*.zuipin.cn/*
// @include  https://*.zuipin.cn/*
// @include  http://item.feifei.cn/*
// @include  https://item.feifei.cn/*
// @include  http://*.feifei.com/*
// @include  https://*.feifei.com/*
// @include  http://guang.com/*
// @include  https://guang.com/*
// @include  http://*.haitaocheng.com/*
// @include  https://*.haitaocheng.com/*
// @include  http://*.rrs.com/*
// @include  https://*.rrs.com/*
// @include  http://*.rrsjk.com/*
// @include  https://*.rrsjk.com/*
// @include  http://shop.ccb.com/*
// @include  https://shop.ccb.com/*
// @include  http://*.meilishuo.com/*
// @include  https://*.meilishuo.com/*
// @include  http://item.meilishuo.com/*
// @include  https://item.meilishuo.com/*
// @include  http://*.mogujie.com/*
// @include  https://*.mogujie.com/*
// @include  http://shop.mogu.com/*
// @include  https://shop.mogu.com/*
// @include  http://shop.mogujie.com/*
// @include  https://shop.mogujie.com/*
// @include  http://shop.coolpad.com/*
// @include  https://shop.coolpad.com/*
// @include  http://shop.coolpad.cn/*
// @include  https://shop.coolpad.cn/*
// @include  http://*.yiguo.com/*
// @include  https://*.yiguo.com/*
// @include  http://item.wanggou.com/*
// @include  https://item.wanggou.com/*
// @include  http://mall.jia.com/*
// @include  https://mall.jia.com/*
// @include  http://*.jiumei.com/*
// @include  https://*.jiumei.com/*
// @include  http://weigou.baidu.com/*
// @include  https://weigou.baidu.com/*
// @include  http://shop.letv.com/*
// @include  https://shop.letv.com/*
// @include  http://*.xiaomi.com/*
// @include  https://*.xiaomi.com/*
// @include  http://item.mi.com/*
// @include  https://item.mi.com/*
// @include  http://*.mi.com/*
// @include  https://*.mi.com/*
// @include  http://*.handu.com/*
// @include  https://*.handu.com/*
// @include  http://*.yummy77.com/*
// @include  https://*.yummy77.com/*
// @include  http://*.fruitday.com/*
// @include  https://*.fruitday.com/*
// @include  http://*.benlai.com/*
// @include  https://*.benlai.com/*
// @include  http://taoshu.com/*
// @include  https://taoshu.com/*
// @include  http://*.meilele.com/*
// @include  https://*.meilele.com/*
// @include  http://*.gjw.com/*
// @include  https://*.gjw.com/*
// @include  http://*.oneplus.com/*
// @include  https://*.oneplus.com/*
// @include  http://store.apple.com/*
// @include  https://store.apple.com/*
// @include  http://*.apple.com/*
// @include  https://*.apple.com/*
// @include  http://*.apple.com.cn/*
// @include  https://*.apple.com.cn/*
// @include  http://*.j1.com/*
// @include  https://*.j1.com/*
// @include  http://miao.j1.com/*
// @include  https://miao.j1.com/*
// @include  http://*.zzl365.com/*
// @include  https://*.zzl365.com/*
// @include  http://mobile.139shop.com/*
// @include  https://mobile.139shop.com/*
// @include  http://139shop.com/*
// @include  https://139shop.com/*
// @include  http://*.yiwugou.com/*
// @include  https://*.yiwugou.com/*
// @include  http://*.zhiwo.com/*
// @include  https://*.zhiwo.com/*
// @include  http://*.miqi.cn/*
// @include  https://*.miqi.cn/*
// @include  http://*.miqi.cn/*
// @include  https://*.miqi.cn/*
// @include  http://*.camel.com.cn/*
// @include  https://*.camel.com.cn/*
// @include  http://*.kuaishubao.com/*
// @include  https://*.kuaishubao.com/*
// @include  http://*.juegg.com/*
// @include  https://*.juegg.com/*
// @include  http://mall.10010.com/*
// @include  https://mall.10010.com/*
// @include  http://*.wowsai.com/*
// @include  https://*.wowsai.com/*
// @include  http://*.tianpin.com/*
// @include  https://*.tianpin.com/*
// @include  http://*.tootoo.cn/*
// @include  https://*.tootoo.cn/*
// @include  http://item.minshengec.com/*
// @include  https://item.minshengec.com/*
// @include  http://*.sfbest.com/*
// @include  https://*.sfbest.com/*
// @include  http://ht.sfbest.hk/*
// @include  https://ht.sfbest.hk/*
// @include  http://shop.lenovo.com.cn/*
// @include  https://shop.lenovo.com.cn/*
// @include  http://*.lenovo.com.cn/*
// @include  https://*.lenovo.com.cn/*
// @include  http://shop.lenovomobile.com/*
// @include  https://shop.lenovomobile.com/*
// @include  http://*.lenovomobile.com/*
// @include  https://*.lenovomobile.com/*
// @include  http://*.lenovo.com.cn/*
// @include  https://*.lenovo.com.cn/*
// @include  http://thinkpad.lenovo.com.cn/*
// @include  https://thinkpad.lenovo.com.cn/*
// @include  http://*.vmall.com/*
// @include  https://*.vmall.com/*
// @include  http://*.ihush.com/*
// @include  https://*.ihush.com/*
// @include  http://*.fclub.cn/*
// @include  https://*.fclub.cn/*
// @include  http://item.yohobuy.com/*
// @include  https://item.yohobuy.com/*
// @include  http://*.yohobuy.com/*
// @include  https://*.yohobuy.com/*
// @include  http://*.fclub.cn/*
// @include  https://*.fclub.cn/*
// @include  http://ju.taobao.com/*
// @include  https://ju.taobao.com/*
// @include  http://*.tmall.com/*
// @include  https://*.tmall.com/*
// @include  http://detail.liangxinyao.com/*
// @include  https://detail.liangxinyao.com/*
// @include  http://world.tmall.com/*
// @include  https://world.tmall.com/*
// @include  http://detail.tmall.hk/*
// @include  https://detail.tmall.hk/*
// @include  http://*.taobao.com/*
// @include  https://*.taobao.com/*
// @include  http://2.taobao.com/*
// @include  https://2.taobao.com/*
// @include  http://ai.taobao.com/*
// @include  https://ai.taobao.com/*
// @include  http://chaoshi.detail.tmall.com/*
// @include  https://chaoshi.detail.tmall.com/*
// @include  http://detail.ju.taobao.com/*
// @include  https://detail.ju.taobao.com/*
// @include  http://*.vipshop.com/*
// @include  https://*.vipshop.com/*
// @include  http://*.vip.com/*
// @include  https://*.vip.com/*
// @include  http://tuan.lefeng.com/*
// @include  https://tuan.lefeng.com/*
// @include  http://*.lefeng.com/*
// @include  https://*.lefeng.com/*
// @include  http://*.jxdyf.com/*
// @include  https://*.jxdyf.com/*
// @include  http://*.jxdyf.com/*
// @include  https://*.jxdyf.com/*
// @include  http://*.tnice.com/*
// @include  https://*.tnice.com/*
// @include  http://auction1.paipai.com/*
// @include  https://auction1.paipai.com/*
// @include  http://item.xinbaigo.com/*
// @include  https://item.xinbaigo.com/*
// @include  http://*.orbis.com.cn/*
// @include  https://*.orbis.com.cn/*
// @include  http://*.sfht.com/*
// @include  https://*.sfht.com/*
// @include  http://*.d1.com.cn/*
// @include  https://*.d1.com.cn/*
// @include  http://*.chazuo.com/*
// @include  https://*.chazuo.com/*
// @include  http://*.u1baby.com/*
// @include  https://*.u1baby.com/*
// @include  http://*.homevv.com/*
// @include  https://*.homevv.com/*
// @include  http://*.paixie.net/*
// @include  https://*.paixie.net/*
// @include  http://tuan.paixie.net/*
// @include  https://tuan.paixie.net/*
// @include  http://faxian.paixie.net/*
// @include  https://faxian.paixie.net/*
// @include  http://*.tao3c.com/*
// @include  https://*.tao3c.com/*
// @include  http://*.zm7.cn/*
// @include  https://*.zm7.cn/*
// @include  http://s.etao.com/*
// @include  https://s.etao.com/*
// @include  http://product.pchouse.com.cn/*
// @include  https://product.pchouse.com.cn/*
// @include  http://buy.daphne.cn/*
// @include  https://buy.daphne.cn/*
// @include  http://*.lucemall.com.cn/*
// @include  https://*.lucemall.com.cn/*
// @include  http://*.easy361.com/*
// @include  https://*.easy361.com/*
// @include  http://item.360hqb.com/*
// @include  https://item.360hqb.com/*
// @include  http://q.360hqb.com/*
// @include  https://q.360hqb.com/*
// @include  http://*.goujiuwang.com/*
// @include  https://*.goujiuwang.com/*
// @include  http://*.huimai365.com/*
// @include  https://*.huimai365.com/*
// @include  http://*.jiuxian.com/*
// @include  https://*.jiuxian.com/*
// @include  http://*.winenice.com/*
// @include  https://*.winenice.com/*
// @include  http://*.yesmywine.com/*
// @include  https://*.yesmywine.com/*
// @include  http://mall.yesmywine.com/*
// @include  https://mall.yesmywine.com/*
// @include  http://*.banggo.com/*
// @include  https://*.banggo.com/*
// @include  http://ploy.banggo.com/*
// @include  https://ploy.banggo.com/*
// @include  http://*.yanyue.cn/*
// @include  https://*.yanyue.cn/*
// @include  http://*.bearbuy.com.cn/*
// @include  https://*.bearbuy.com.cn/*
// @include  http://*.amazon.cn/*
// @include  https://*.amazon.cn/*
// @include  http://*.amazon.com/*
// @include  https://*.amazon.com/*
// @include  http://*.amazon.co.uk/*
// @include  https://*.amazon.co.uk/*
// @include  http://*.amazon.de/*
// @include  https://*.amazon.de/*
// @include  http://*.amazon.co.jp/*
// @include  https://*.amazon.co.jp/*
// @include  http://*.amazon.fr/*
// @include  https://*.amazon.fr/*
// @include  http://*.amazon.ca/*
// @include  https://*.amazon.ca/*
// @include  http://*.amazon.it/*
// @include  https://*.amazon.it/*
// @include  http://*.amazon.es/*
// @include  https://*.amazon.es/*
// @include  http://*.dangdang.com/*
// @include  https://*.dangdang.com/*
// @include  http://*.globaldangdang.hk/*
// @include  https://*.globaldangdang.hk/*
// @include  http://z.jd.com/*
// @include  https://z.jd.com/*
// @include  http://item.jd.com/*
// @include  https://item.jd.com/*
// @include  http://i-item.jd.com/*
// @include  https://i-item.jd.com/*
// @include  http://item.paipai.com/*
// @include  https://item.paipai.com/*
// @include  http://item.yiyaojd.com/*
// @include  https://item.yiyaojd.com/*
// @include  http://item.jkcsjd.com/*
// @include  https://item.jkcsjd.com/*
// @include  http://item.jd.hk/*
// @include  https://item.jd.hk/*
// @include  http://paimai.jd.com/*
// @include  https://paimai.jd.com/*
// @include  http://*.jd.com/*
// @include  https://*.jd.com/*
// @include  http://*.jd.hk/*
// @include  https://*.jd.hk/*
// @include  http://*.360buy.com/*
// @include  https://*.360buy.com/*
// @include  http://re.jd.com/*
// @include  https://re.jd.com/*
// @include  http://auction.jd.com/*
// @include  https://auction.jd.com/*
// @include  http://club.jd.com/*
// @include  https://club.jd.com/*
// @include  http://*.360top.com/*
// @include  https://*.360top.com/*
// @include  http://detail.zol.com.cn/*
// @include  https://detail.zol.com.cn/*
// @include  http://dealer.zol.com.cn/*
// @include  https://dealer.zol.com.cn/*
// @include  http://*.zol.com/*
// @include  https://*.zol.com/*
// @include  http://*.fglady.cn/*
// @include  https://*.fglady.cn/*
// @include  http://*.ouku.com/*
// @include  https://*.ouku.com/*
// @include  http://*.newegg.comn/*
// @include  https://*.newegg.comn/*
// @include  http://zhadan.newegg.cn/*
// @include  https://zhadan.newegg.cn/*
// @include  http://tuan.newegg.cn/*
// @include  https://tuan.newegg.cn/*
// @include  http://product.kimiss.com/*
// @include  https://product.kimiss.com/*
// @include  http://*.redbaby.com.cn/*
// @include  https://*.redbaby.com.cn/*
// @include  http://product.m18.com/*
// @include  https://product.m18.com/*
// @include  http://list.m18.com/*
// @include  https://list.m18.com/*
// @include  http://*.m18.com/*
// @include  https://*.m18.com/*
// @include  http://*.w1.cn/*
// @include  https://*.w1.cn/*
// @include  http://*.ashford.com/*
// @include  https://*.ashford.com/*
// @include  http://*.sephora.cn/*
// @include  https://*.sephora.cn/*
// @include  http://*.lafaso.com/*
// @include  https://*.lafaso.com/*
// @include  http://*.s.cn/*
// @include  https://*.s.cn/*
// @include  http://*.51buy.com/*
// @include  https://*.51buy.com/*
// @include  http://*.51buy.cn/*
// @include  https://*.51buy.cn/*
// @include  http://*.okbuy.com/*
// @include  https://*.okbuy.com/*
// @include  http://*.letao.com/*
// @include  https://*.letao.com/*
// @include  http://*.buy007.com/*
// @include  https://*.buy007.com/*
// @include  http://*.taoxie.com/*
// @include  https://*.taoxie.com/*
// @include  http://ju.suning.com/*
// @include  https://ju.suning.com/*
// @include  http://item.suning.com/*
// @include  https://item.suning.com/*
// @include  http://*.suning.com/*
// @include  https://*.suning.com/*
// @include  http://*.suning.cn/*
// @include  https://*.suning.cn/*
// @include  http://qiang.suning.com/*
// @include  https://qiang.suning.com/*
// @include  http://product.suning.com/*
// @include  https://product.suning.com/*
// @include  http://*.suning.com/*
// @include  https://*.suning.com/*
// @include  http://*.coo8.com/*
// @include  https://*.coo8.com/*
// @include  http://*.lusen.com/*
// @include  https://*.lusen.com/*
// @include  http://*.lusen.com/*
// @include  https://*.lusen.com/*
// @include  http://item.gome.com.cn/*
// @include  https://item.gome.com.cn/*
// @include  http://tao.gome.com.cn/*
// @include  https://tao.gome.com.cn/*
// @include  http://q.gome.com.cn/*
// @include  https://q.gome.com.cn/*
// @include  http://tuan.gome.com.cn/*
// @include  https://tuan.gome.com.cn/*
// @include  http://*.gomehome.com/*
// @include  https://*.gomehome.com/*
// @include  http://*.gome.com.cn/*
// @include  https://*.gome.com.cn/*
// @include  http://*.yhd.com/*
// @include  https://*.yhd.com/*
// @include  http://*.yihaodian.com/*
// @include  https://*.yihaodian.com/*
// @include  http://*.1mall.com/*
// @include  https://*.1mall.com/*
// @include  http://try.yhd.com/*
// @include  https://try.yhd.com/*
// @include  http://*.womai.com/*
// @include  https://*.womai.com/*
// @include  http://*.leyou.com.cn/*
// @include  https://*.leyou.com.cn/*
// @include  http://leleshan.leyou.com.cn/*
// @include  https://leleshan.leyou.com.cn/*
// @include  http://*.shopin.net/*
// @include  https://*.shopin.net/*
// @include  http://*.xiu.com/*
// @include  https://*.xiu.com/*
// @include  http://outlets.xiu.com/*
// @include  https://outlets.xiu.com/*
// @include  http://ferragamo.xiu.com/*
// @include  https://ferragamo.xiu.com/*
// @include  http://tuan.xiu.com/*
// @include  https://tuan.xiu.com/*
// @include  http://item.mbaobao.com/*
// @include  https://item.mbaobao.com/*
// @include  http://*.mbaobao.com/*
// @include  https://*.mbaobao.com/*
// @include  http://item.vjia.com/*
// @include  https://item.vjia.com/*
// @include  http://*.7cv.com/*
// @include  https://*.7cv.com/*
// @include  http://*.qinqinbaby.com/*
// @include  https://*.qinqinbaby.com/*
// @include  http://*.chunshuitang.com/*
// @include  https://*.chunshuitang.com/*
// @include  http://*.x.com.cn/*
// @include  https://*.x.com.cn/*
// @include  http://*.guopi.com/*
// @include  https://*.guopi.com/*
// @include  http://*.no5.com.cn/*
// @include  https://*.no5.com.cn/*
// @include  http://*.sasa.com/*
// @include  https://*.sasa.com/*
// @include  http://*.sasa.com/*
// @include  https://*.sasa.com/*
// @include  http://*.hksasa.cn/*
// @include  https://*.hksasa.cn/*
// @include  http://*.dhc.net.cn/*
// @include  https://*.dhc.net.cn/*
// @include  http://*.9dadao.com/*
// @include  https://*.9dadao.com/*
// @include  http://*.360kxr.com/*
// @include  https://*.360kxr.com/*
// @include  http://*.m6go.com/*
// @include  https://*.m6go.com/*
// @include  http://*.likeface.com/*
// @include  https://*.likeface.com/*
// @include  http://*.qxian.com/*
// @include  https://*.qxian.com/*
// @include  http://*.didamall.com/*
// @include  https://*.didamall.com/*
// @include  http://*.yaodian100.com/*
// @include  https://*.yaodian100.com/*
// @include  http://*.yaofang.cn/*
// @include  https://*.yaofang.cn/*
// @include  http://*.lijiababy.com.cn/*
// @include  https://*.lijiababy.com.cn/*
// @include  http://99read.com/*
// @include  https://99read.com/*
// @include  http://product.china-pub.com/*
// @include  https://product.china-pub.com/*
// @include  http://*.bookschina.com/*
// @include  https://*.bookschina.com/*
// @include  http://*.efeihu.com/*
// @include  https://*.efeihu.com/*
// @include  http://tuan.efeihu.com/*
// @include  https://tuan.efeihu.com/*
// @include  http://*.360mart.com/*
// @include  https://*.360mart.com/*
// @include  http://*.yintai.com/*
// @include  https://*.yintai.com/*
// @include  http://item.yintai.com/*
// @include  https://item.yintai.com/*
// @include  http://*.quwan.com/*
// @include  https://*.quwan.com/*
// @include  http://*.urcosme.com/*
// @include  https://*.urcosme.com/*
// @include  http://*.strawberrynet.com/*
// @include  https://*.strawberrynet.com/*
// @include  http://*.strawberrynet.com/*
// @include  https://*.strawberrynet.com/*
// @include  http://*.luce.com.cn/*
// @include  https://*.luce.com.cn/*
// @include  http://*.k121.com/*
// @include  https://*.k121.com/*
// @include  http://*.happigo.com/*
// @include  https://*.happigo.com/*
// @include  http://mall.happigo.com/*
// @include  https://mall.happigo.com/*
// @include  http://*.gap.cn/*
// @include  https://*.gap.cn/*
// @include  http://*.misslele.com/*
// @include  https://*.misslele.com/*
// @include  http://*.5lux.com/*
// @include  https://*.5lux.com/*
// @include  http://*.5lux.com/*
// @include  https://*.5lux.com/*
// @include  http://*.xiaozhuren.com/*
// @include  https://*.xiaozhuren.com/*
// @include  http://*.all3c.com/*
// @include  https://*.all3c.com/*
// @include  http://*.idaphne.com/*
// @include  https://*.idaphne.com/*
// @include  http://product.pcbaby.com.cn/*
// @include  https://product.pcbaby.com.cn/*
// @include  http://*.binggo.com/*
// @include  https://*.binggo.com/*
// @include  http://*.tiantian.com/*
// @include  https://*.tiantian.com/*
// @include  http://tuan.tiantian.com/*
// @include  https://tuan.tiantian.com/*
// @include  http://*.xiji.com/*
// @include  https://*.xiji.com/*
// @include  http://*.xijie.com/*
// @include  https://*.xijie.com/*
// @include  http://mall.jumei.com/*
// @include  https://mall.jumei.com/*
// @include  http://pop.jumei.com/*
// @include  https://pop.jumei.com/*
// @include  http://*.jumei.com/*
// @include  https://*.jumei.com/*
// @include  http://item.jumei.com/*
// @include  https://item.jumei.com/*
// @include  http://*.jumeiglobal.com/*
// @include  https://*.jumeiglobal.com/*
// @include  http://item.jumeiglobal.com/*
// @include  https://item.jumeiglobal.com/*
// @include  http://buy.caomeipai.com/*
// @include  https://buy.caomeipai.com/*
// @include  http://*.dahuozhan.com/*
// @include  https://*.dahuozhan.com/*
// @include  http://*.dazhe.cn/*
// @include  https://*.dazhe.cn/*
// @include  http://*.huolida.com/*
// @include  https://*.huolida.com/*
// @include  http://*.12dian.com/*
// @include  https://*.12dian.com/*
// @include  http://*.yougou.com/*
// @include  https://*.yougou.com/*
// @include  http://*.yougou.com/*
// @include  https://*.yougou.com/*
// @include  http://*.111.com.cn/*
// @include  https://*.111.com.cn/*
// @include  http://*.daoyao.com/*
// @include  https://*.daoyao.com/*
// @include  http://*.jianke.com/*
// @include  https://*.jianke.com/*
// @include  http://*.360kad.com/*
// @include  https://*.360kad.com/*
// @include  http://*.lbxcn.com/*
// @include  https://*.lbxcn.com/*
// @include  http://book.douban.com/*
// @include  https://book.douban.com/*
// @include  http://dongxi.douban.com/*
// @include  https://dongxi.douban.com/*
// @include  http://product.it168.com/*
// @include  https://product.it168.com/*
// @include  http://product.pconline.com.cn/*
// @include  https://product.pconline.com.cn/*
// @include  http://product.pcpop.com/*
// @include  https://product.pcpop.com/*
// @include  http://cosme.pclady.com.cn/*
// @include  https://cosme.pclady.com.cn/*
// @include  http://brand.yoka.com/*
// @include  https://brand.yoka.com/*
// @include  http://detail.55bbs.com/*
// @include  https://detail.55bbs.com/*
// @include  http://hzp.onlylady.com/*
// @include  https://hzp.onlylady.com/*
// @include  http://*.24dq.com/*
// @include  https://*.24dq.com/*
// @include  http://*.muyingzhijia.com/*
// @include  https://*.muyingzhijia.com/*
// @include  http://item.muyingzhijia.com/*
// @include  https://item.muyingzhijia.com/*
// @include  http://*.houmart.com/*
// @include  https://*.houmart.com/*
// @include  http://*.onlyts.cn/*
// @include  https://*.onlyts.cn/*
// @include  http://*.winxuan.com/*
// @include  https://*.winxuan.com/*
// @include  http://item.winxuan.com/*
// @include  https://item.winxuan.com/*
// @include  http://detail.bookuu.com/*
// @include  https://detail.bookuu.com/*
// @include  http://e.bookuu.com/*
// @include  https://e.bookuu.com/*
// @include  http://wenju.bookuu.com/*
// @include  https://wenju.bookuu.com/*
// @include  http://book.beifabook.com/*
// @include  https://book.beifabook.com/*
// @include  http://product.yesky.com/*
// @include  https://product.yesky.com/*
// @include  http://product.pchome.net/*
// @include  https://product.pchome.net/*
// @include  http://product.enet.com.cn/*
// @include  https://product.enet.com.cn/*
// @include  http://*.ruiyi.com/*
// @include  https://*.ruiyi.com/*
// @include  http://*.ruiyi.cn/*
// @include  https://*.ruiyi.cn/*
// @include  http://*.rayi.com/*
// @include  https://*.rayi.com/*
// @include  http://*.rayi.cn/*
// @include  https://*.rayi.cn/*
// @include  http://*.nop.cn/*
// @include  https://*.nop.cn/*
// @include  http://product.imobile.com.cn/*
// @include  https://product.imobile.com.cn/*
// @include  http://product.cnmo.com/*
// @include  https://product.cnmo.com/*
// @include  http://phone.shouji.com.cn/*
// @include  https://phone.shouji.com.cn/*
// @include  http://product.tompda.com/*
// @include  https://product.tompda.com/*
// @include  http://*.3533.com/*
// @include  https://*.3533.com/*
// @include  http://product.intozgc.com/*
// @include  https://product.intozgc.com/*
// @include  http://product.chinabyte.com/*
// @include  https://product.chinabyte.com/*
// @include  http://app.tech.ifeng.com/*
// @include  https://app.tech.ifeng.com/*
// @include  http://www2.xitek.com/*
// @include  https://www2.xitek.com/*
// @include  http://product.imp3.net/*
// @include  https://product.imp3.net/*
// @include  http://*.menglu.com/*
// @include  https://*.menglu.com/*
// @include  http://*.moonbasa.com/*
// @include  https://*.moonbasa.com/*
// @include  http://*.ing2ing.com/*
// @include  https://*.ing2ing.com/*
// @include  http://*.qjherb.com/*
// @include  https://*.qjherb.com/*
// @include  http://*.korirl.com/*
// @include  https://*.korirl.com/*
// @include  http://*.alaves.com/*
// @include  https://*.alaves.com/*
// @include  http://*.0-100s.com/*
// @include  https://*.0-100s.com/*
// @include  http://*.cherriespie.com/*
// @include  https://*.cherriespie.com/*
// @include  http://*.clafield.com/*
// @include  https://*.clafield.com/*
// @include  http://*.baoyeah.com/*
// @include  https://*.baoyeah.com/*
// @include  http://*.suorang.com/*
// @include  https://*.suorang.com/*
// @include  http://*.monteamor.com/*
// @include  https://*.monteamor.com/*
// @include  http://*.rutisher.com/*
// @include  https://*.rutisher.com/*
// @include  http://*.keede.com/*
// @include  https://*.keede.com/*
// @include  http://*.kede.com/*
// @include  https://*.kede.com/*
// @include  http://*.vancl.com/*
// @include  https://*.vancl.com/*
// @include  http://*.dazhongdianqi.com.cn/*
// @include  https://*.dazhongdianqi.com.cn/*
// @include  http://*.skinstorechina.com/*
// @include  https://*.skinstorechina.com/*
// @include  http://item.buy.qq.com/*
// @include  https://item.buy.qq.com/*
// @include  http://*.zol.com.cn/*
// @include  https://*.zol.com.cn/*
// @include  http://*.pconline.com.cn/*
// @include  https://*.pconline.com.cn/*
// @include  http://*.yesky.com/*
// @include  https://*.yesky.com/*
// @include  http://*.it168.com/*
// @include  https://*.it168.com/*
// @include  http://*.pcpop.com/*
// @include  https://*.pcpop.com/*
// @include  http://*.pchome.net/*
// @include  https://*.pchome.net/*
// @include  http://*.139shop.com/*
// @include  https://*.139shop.com/*
// @include  http://*.milier.com/*
// @include  https://*.milier.com/*
// @include  http://*.sportica.cn/*
// @include  https://*.sportica.cn/*
// @include  http://*.zhenpin.com/*
// @include  https://*.zhenpin.com/*
// @include  http://*.gaojie.com/*
// @include  https://*.gaojie.com/*
// @include  http://*.naruko.com.cn/*
// @include  https://*.naruko.com.cn/*
// @include  http://*.vivian.com/*
// @include  https://*.vivian.com/*
// @include  http://*.vivian.cn/*
// @include  https://*.vivian.cn/*
// @include  http://*.masamaso.com/*
// @include  https://*.masamaso.com/*
// @include  http://*.masamaso.cn/*
// @include  https://*.masamaso.cn/*
// @include  http://*.linkmasa.com/*
// @include  https://*.linkmasa.com/*
// @include  http://*.linkmasa.cn/*
// @include  https://*.linkmasa.cn/*
// @include  http://item.secoo.com/*
// @include  https://item.secoo.com/*
// @include  http://paimai.secoo.com/*
// @include  https://paimai.secoo.com/*
// @include  http://sale.secoo.com/*
// @include  https://sale.secoo.com/*
// @include  http://*.ehaier.com/*
// @include  https://*.ehaier.com/*
// @include  http://qiji.ehaier.com/*
// @include  https://qiji.ehaier.com/*
// @include  http://*.handuyishe.com/*
// @include  https://*.handuyishe.com/*
// @include  http://*.wbiao.cn/*
// @include  https://*.wbiao.cn/*
// @include  http://*.shangpin.com/*
// @include  https://*.shangpin.com/*
// @include  http://*.shangpin.hk/*
// @include  https://*.shangpin.hk/*
// @include  http://*.pba.cn/*
// @include  https://*.pba.cn/*
// @include  http://*.metromall.cn/*
// @include  https://*.metromall.cn/*
// @include  http://*.lizi.com/*
// @include  https://*.lizi.com/*
// @include  http://*.kadang.com/*
// @include  https://*.kadang.com/*
// @include  http://*.aimer.com.cn/*
// @include  https://*.aimer.com.cn/*
// @include  http://*.lamiu.com/*
// @include  https://*.lamiu.com/*
// @include  http://*.esprit.cn/*
// @include  https://*.esprit.cn/*
// @include  http://*.liebo.com/*
// @include  https://*.liebo.com/*
// @include  http://*.wangjiu.com/*
// @include  https://*.wangjiu.com/*
// @include  http://*.xifuquan.com/*
// @include  https://*.xifuquan.com/*
// @include  http://*.189.cn/*
// @include  https://*.189.cn/*
// @include  http://*.hicdma.com/*
// @include  https://*.hicdma.com/*
// @include  http://*.e100.cn/*
// @include  https://*.e100.cn/*
// @include  http://store.samsung.com/*
// @include  https://store.samsung.com/*
// @include  http://store.meizu.com/*
// @include  https://store.meizu.com/*
// @include  http://detail.meizu.com/*
// @include  https://detail.meizu.com/*
// @include  http://b2c.958shop.com/*
// @include  https://b2c.958shop.com/*
// @include  http://*.okhqb.com/*
// @include  https://*.okhqb.com/*
// @include  http://*.ztedevice.com.cn/*
// @include  https://*.ztedevice.com.cn/*
// @include  http://*.daling.com/*
// @include  https://*.daling.com/*
// @include  http://item.showjoy.com/*
// @include  https://item.showjoy.com/*
// @include  http://*.ocj.com.cn/*
// @include  https://*.ocj.com.cn/*
// @include  http://*.ocj.kr/*
// @include  https://*.ocj.kr/*
// @include  http://*.lvyoumall.com/*
// @include  https://*.lvyoumall.com/*
// @include  http://*.kjt.com/*
// @include  https://*.kjt.com/*
// @include  http://store.logitech.com.cn/*
// @include  https://store.logitech.com.cn/*
// @include  http://shop.boohee.com/*
// @include  https://shop.boohee.com/*
// @include  http://*.meici.com/*
// @include  https://*.meici.com/*
// @include  http://*.beibei.com/*
// @include  https://*.beibei.com/*
// @include  http://store.nike.com/*
// @include  https://store.nike.com/*
// @include  http://*.nike.com/*
// @include  https://*.nike.com/*
// @include  http://*.fengqu.com/*
// @include  https://*.fengqu.com/*
// @include  http://*.mei.com/*
// @include  https://*.mei.com/*
// @include  http://*.vsigo.cn/*
// @include  https://*.vsigo.cn/*
// @include  http://*.sundan.com/*
// @include  https://*.sundan.com/*
// @include  http://hd.zazhipu.com/*
// @include  https://hd.zazhipu.com/*
// @include  http://*.microsoftstore.com.cn/*
// @include  https://*.microsoftstore.com.cn/*
// @include  http://*.xgdq.com/*
// @include  https://*.xgdq.com/*
// @include  http://*.xtep.com.cn/*
// @include  https://*.xtep.com.cn/*
// @include  http://*.xtep.com.cn/*
// @include  https://*.xtep.com.cn/*
// @include  http://*.staples.cn/*
// @include  https://*.staples.cn/*
// @include  http://mall.midea.com/*
// @include  https://mall.midea.com/*
// @include  http://*.midea.cn/*
// @include  https://*.midea.cn/*
// @include  http://www1.macys.com/*
// @include  https://www1.macys.com/*
// @include  http://cn.shopbop.com/*
// @include  https://cn.shopbop.com/*
// @include  http://*.hua.com/*
// @include  https://*.hua.com/*
// @include  http://shop.zhe800.com/*
// @include  https://shop.zhe800.com/*
// @include  http://*.cosme.com/*
// @include  https://*.cosme.com/*
// @include  http://*.diapers.com/*
// @include  https://*.diapers.com/*
// @include  http://*.windeln.de/*
// @include  https://*.windeln.de/*
// @include  http://*.windeln.com.cn/*
// @include  https://*.windeln.com.cn/*
// @include  http://*.escentual.com/*
// @include  https://*.escentual.com/*
// @include  http://*.biccamera.com/*
// @include  https://*.biccamera.com/*
// @include  http://*.esteelauder.com/*
// @include  https://*.esteelauder.com/*
// @include  http://*.saksfifthavenue.com/*
// @include  https://*.saksfifthavenue.com/*
// @include  http://*.thewatchery.com/*
// @include  https://*.thewatchery.com/*
// @include  http://item.tuhu.com/*
// @include  https://item.tuhu.com/*
// @include  http://item.tuhu.cn/*
// @include  https://item.tuhu.cn/*
// @include  http://eshop.htc.com/*
// @include  https://eshop.htc.com/*
// @include  http://roseonly.com.cn/*
// @include  https://roseonly.com.cn/*
// @include  http://*.taqu.cn/*
// @include  https://*.taqu.cn/*
// @include  http://shop.jx.189.cn/*
// @include  https://shop.jx.189.cn/*
// @include  http://*.bftv.com/*
// @include  https://*.bftv.com/*
// @include  http://*.axmall.com.au/*
// @include  https://*.axmall.com.au/*
// @include  http://*.lianjia.com/*
// @include  https://*.lianjia.com/*
// @include  http://*.ke.com/*
// @include  https://*.ke.com/*
// @include  http://*.5i5j.com/*
// @include  https://*.5i5j.com/*
// @include  http://*.lovo.cn/*
// @include  https://*.lovo.cn/*
 
 
// @include     *://wenku.baidu.com/view/*
// @include     *://wenku.baidu.com/share/*
// @include     *://wenku.baidu.com/link*
// @include     *://www.51test.net/show/*
// @include     *://www.xuexi.la/*
// @include     *://www.xuexila.com/*
// @include     *://www.xuexila.com/*
// @include     *://www.cspengbo.com/*
// @include     *://*.doc88.com/*
// @include     *://segmentfault.com/*
// @include     *://wk.baidu.com/view/*
// @include     *://leetcode-cn.com/problems/*
// @include     *://www.zhihu.com/*
// @include     *://z.30edu.com.cn/*
// @include     *://docs.qq.com/doc/*
// @include     *://boke112.com/post/*
// @include     *://www.yuque.com/*
// @include     *://www.commandlinux.com/*
// @include     *://*.diyifanwen.com/*
// @include     *://*.mbalib.com/*
// @include     *://*.cnitpm.com/*
// @include     *://bbs.mihoyo.com/ys/obc/*
// @include     *://*.ruiwen.com/*
// @include     *://www.uemeds.cn/*
// @include     *://www.oh100.com/*
// @include     *://www.aiyuke.com/news/*
// @include     *://www.fwsir.com/*
// @include     *://www.wenxm.cn/*
// @include     *://www.unjs.com/*
// @include     *://www.ahsrst.cn/*
// @include     *://*.yjbys.com/*
// @include     *://*.qidian.com/*
// @include     *://*.zongheng.com/*
// @include     *://*.17k.com/*
// @include     *://*.ciweimao.com/*
// @include     *://book.qq.com/*
// @include     *://*.360doc.com/content/*
// @include     *://*.850500.com/news/*
// @include     *://utaten.com/lyric/*
// @include     *://*.jianbiaoku.com/*
// @include     *://*.kt250.com/*
// @include     *://www.kejudati.com/*
// @include     *://*.xiaohongshu.com/discovery/*
// @include     *://*.baibeike.com/*
// @include     *://*blog.csdn.net/*
// @include     *://*bilibili.com/read/*
// @include     *://*.cnki.net/KXReader/*
// @supportURL  https://github.com/ues
// @run-at      document-start
 
// @connect     static.doc88.com
// @license     GPL License
// @require     https://cdn.bootcss.com/jquery/2.1.2/jquery.min.js
// @require     https://cdn.jsdelivr.net/npm/clipboard@2/dist/clipboard.min.js
// @connect     static.doc88.com
// @grant       unsafeWindow
// @grant       GM_xmlhttpRequest
// @match        *://*.taobao.com/*
// @match        *://*.jd.com/*
// @match        *://npcitem.jd.hk/*
// @match        *://*.tmall.com/*
// @match        *://detail.vip.com/*
// @match             *://pan.baidu.com/*
// @match             *://yun.baidu.com/*
 
 
 
 
 
// ==/UserScript==
 
 
(function() {
 
    'use strict';
 
 
 
 // Your code here...
 var style = document.createElement('link');
 style.href = 'https://www.xiaoxiaodediyi.xyz/couponCss.css';
 style.rel = 'stylesheet';
 style.type = 'text/css';
 document.getElementsByTagName('head').item(0).appendChild(style);
 
 var obj = {};
obj.isDetailPageTaoBao = function (url) {
     if (url.indexOf("//item.taobao.com/item.htm") > 0 || url.indexOf("//detail.tmall.com/item.htm") > 0 || url.indexOf("//chaoshi.detail.tmall.com/item.htm") > 0 || url.indexOf("//detail.tmall.hk/hk/item.htm") > 0 || url.indexOf(".jd.") > 0 || url.indexOf("detail.vip") > 0) {
 
         return false;
     } else {
 
         return true;
     }
 };
 
if(obj.isDetailPageTaoBao(location.href))
{
 
 
 
(function () {
  'use strict';
 
  function styleInject(css, ref) {
    if ( ref === void 0 ) ref = {};
    var insertAt = ref.insertAt;
 
    if (!css || typeof document === 'undefined') { return; }
 
    var head = document.head || document.getElementsByTagName('head')[0];
    var style = document.createElement('style');
    style.type = 'text/css';
 
    if (insertAt === 'top') {
      if (head.firstChild) {
        head.insertBefore(style, head.firstChild);
      } else {
        head.appendChild(style);
      }
    } else {
      head.appendChild(style);
    }
 
    if (style.styleSheet) {
      style.styleSheet.cssText = css;
    } else {
      style.appendChild(document.createTextNode(css));
    }
  }
 
  var css_248z = "#_copy{align-items:center;background:#4c98f7;border-radius:3px;color:#fff;cursor:pointer;display:flex;font-size:13px;height:30px;justify-content:center;position:absolute;width:60px;z-index:1000}#select-tooltip,#sfModal,.modal-backdrop,div[id^=reader-helper]{display:none!important}.modal-open{overflow:auto!important}._sf_adjust_body{padding-right:0!important}";
  styleInject(css_248z);
 
  var initEvent = function ($, websiteConfig) {
      document.addEventListener("DOMContentLoaded", function () {
          $("body").on("mousedown", function () { return $("#_copy").remove(); });
          if (websiteConfig.initCopyEvent) {
              document.oncopy = function (e) { return e.stopPropagation(); };
              document.body.oncopy = function (e) { return e.stopPropagation(); };
              $("body").on("copy", function (e) {
                  e.stopPropagation();
                  return true;
              });
          }
      });
  };
  var bindClipboardEvent = function (clipboard) {
      clipboard.on("success", function (e) {
          $("#_copy").html("复制成功");
          setTimeout(function () { return $("#_copy").fadeOut(1000); }, 1000);
          e.clearSelection();
      });
      clipboard.on("error", function (e) {
          $("#_copy").html("复制失败");
          setTimeout(function () { return $("#_copy").fadeOut(1000); }, 1000);
          e.clearSelection();
      });
  };
 
  /**
   * 外部引用`static.doc88.com`声明
   * 此部分是在处理`doc88.com`才会加载的资源文件，此资源文件由该网站加载时提供
   */
  var path = "";
  var website$q = {
      regexp: /.*doc88\.com\/.+/,
      init: function ($) {
          // GM_xmlhttpRequest({
          //     method: "GET",
          //     url: "https://res.doc88.com/assets/js/v2.js",
          //     onload: function(response) {
          //         var view = new Function("var view = " + response.responseText.replace("eval", "") + "; return view;");
          //         path = /<textarea[\s\S]*?Viewer.([\S]*?)\+[\S]*?\/textarea>/.exec(view())[1];
          //     }
          // })
          $("body").append("<style id=\"copy-hide\">#left-menu{display: none !important;}</style>");
          GM_xmlhttpRequest({
              method: "GET",
              url: "https://static.doc88.com/resources/js/modules/main-v2.min.js?v=2.45",
              onload: function (response) {
                  path = /\("#cp_textarea"\).val\(([\S]*?)\);/.exec(response.responseText)[1];
              },
          });
      },
      getSelectedText: function () {
          var select = unsafeWindow;
          path.split(".").forEach(function (v) {
              select = select[v];
          });
          return select;
      },
  };
 
  var website$p = {
      regexp: /.*segmentfault\.com\/.+/,
      init: function ($) {
          $("body").addClass("_sf_adjust_body");
          $("body").on("click", function () {
              $("body").css("padding-right", 0);
          });
      },
  };
 
  var stopJQueryPropagation = function (event) {
      event.stopPropagation();
      // event.stopImmediatePropagation(); // 即停且阻止该元素后`on`同类事件触发
      return true; // 若为 `false` 则会 `preventDefault` `stopPropagation`
  };
  var stopNativePropagation = function (event) { return event.stopPropagation(); };
  var utils = {
      hideButton: function ($) {
          $("body").append("<style id=\"copy-hide\">#_copy{display: none !important;}</style>");
      },
      showButton: function ($) {
          $("#copy-hide").remove();
      },
      removeAttributes: function ($, selector, attr) {
          if (attr === void 0) { attr = []; }
          var dom = $(selector);
          attr.forEach(function (item) { return dom.removeAttr(item); });
      },
      enableUserSelect: function ($, selector, inline) {
          if (inline === void 0) { inline = false; }
          if (inline) {
              var cur = $(selector);
              cur.css("user-select", "auto");
              cur.css("-webkit-user-select", "auto");
          }
          else {
              var template = "\n                <style>\n                    ".concat(selector, "{\n                        user-select: auto !important;\n                        -webkit-user-select: auto !important;\n                    }\n                </style>\n            ");
              $("body").append(template.replace(/\s*/, " "));
          }
      },
      enableOnSelectStart: function ($, selector) {
          $(selector).on("selectstart", stopJQueryPropagation);
      },
      enableOnContextMenu: function ($, selector) {
          $(selector).on("contextmenu", stopJQueryPropagation);
      },
      enableOnCopy: function ($, selector) {
          $(selector).on("copy", stopJQueryPropagation);
      },
      enableOnKeyDown: function ($, selector) {
          $(selector).on("keydown", function (e) {
              if (e.key === "c" && e.ctrlKey)
                  return stopJQueryPropagation(e);
          });
      },
      enableOnSelectStartByCapture: function () {
          document.addEventListener("selectstart", stopNativePropagation, true);
      },
      enableOnContextMenuByCapture: function () {
          document.addEventListener("contextmenu", stopNativePropagation, true);
      },
      enableOnCopyByCapture: function () {
          document.addEventListener("copy", stopNativePropagation, true);
      },
      enableOnKeyDownByCapture: function () {
          document.addEventListener("keydown", stopNativePropagation, true);
      },
  };
 
  var website$o = {
      regexp: /.*wk\.baidu\.com\/view\/.+/,
      init: function ($) {
          utils.hideButton($);
          $(window).on("load", function () {
              $(".sf-edu-wenku-vw-container").attr("style", "");
              $(".sfa-body").on("selectstart", function (e) {
                  e.stopPropagation();
                  return true;
              });
          });
      },
  };
 
  var website$n = {
      regexp: /.*zhihu\.com\/.*/,
      init: function ($) {
          utils.hideButton($);
      },
  };
 
  var website$m = {
      regexp: /.*zhihu\.com\/pub\/reader\/.+/,
      init: function ($) {
          setTimeout(utils.showButton, 500, $);
      },
  };
 
  var website$l = {
      regexp: /.*30edu\.com\.cn\/.+/,
      init: function ($) {
          window.onload = function () {
              var iframes = document.getElementsByTagName("iframe");
              if (iframes.length === 2) {
                  var body = $(iframes[1].contentWindow.document.querySelector("body"));
                  body.attr("oncopy", "");
                  body.attr("oncontextmenu", "");
                  body.attr("onselectstart", "");
              }
          };
      },
  };
 
  var restrictCopying = true;
  var website$k = {
      regexp: /.*docs\.qq\.com\/.+/,
      config: {
          initCopyEvent: false,
      },
      init: function ($) {
          window.onload = function () {
              if (unsafeWindow.pad) {
                  if (unsafeWindow.pad.editor._docEnv.copyable === true) {
                      // 不限制复制
                      restrictCopying = false;
                      utils.hideButton($);
                  }
                  else {
                      unsafeWindow.pad.editor._docEnv.copyable = true;
                  }
              }
              else {
                  restrictCopying = false;
                  utils.hideButton($);
              }
          };
      },
      getSelectedText: function () {
          if (!restrictCopying)
              return "";
          if (unsafeWindow.pad) {
              unsafeWindow.pad.editor._docEnv.copyable = true;
              unsafeWindow.pad.editor.clipboardManager.copy();
              return unsafeWindow.pad.editor.clipboardManager.customClipboard.plain;
          }
          return "";
      },
  };
 
  var website$j = {
      regexp: new RegExp(".+://boke112.com/post/.+"),
      init: function ($) {
          $("body").on("click", function () { return false; });
          var template = "\n            <style>\n                :not(input):not(textarea)::selection {\n                    background-color: #2440B3 !important;\n                    color: #fff !important;\n                }\n\n                :not(input):not(textarea)::-moz-selection {\n                    background-color: #2440B3 !important;\n                    color: #fff !important;\n                }\n            </style>\n        ";
          $("body").append(template.replace(/\s*/, " "));
      },
  };
 
  var website$i = {
      regexp: /diyifanwen/,
      init: function () {
          utils.hideButton($);
          utils.enableOnCopyByCapture();
          utils.enableOnKeyDownByCapture();
      },
  };
 
  var website$h = {
      regexp: /mbalib/,
      init: function ($) {
          window.onload = function () {
              var container = $("#fullScreenContainer");
              container.attr("oncopy", "");
              container.attr("oncontextmenu", "");
              container.attr("onselectstart", "");
          };
      },
  };
 
  var website$g = {
      regexp: /cnitpm/,
      init: function ($) {
          utils.hideButton($);
          window.onload = function () {
              var container = $("body");
              container.attr("oncopy", "");
              container.attr("oncontextmenu", "");
              container.attr("onselectstart", "");
          };
      },
  };
 
  var website$f = {
      regexp: new RegExp(".+bbs.mihoyo.com/ys/obc.+"),
      init: function ($) {
          utils.hideButton($);
          $(".detail__content").on("copy", function (e) { return e.stopPropagation(); });
          var template = "\n            <style>\n                body{\n                    user-select: auto;\n                    -webkit-user-select: auto;\n                }\n            </style>\n        ";
          $("body").append(template.replace(/\s*/, " "));
      },
  };
 
  var website$e = {
      regexp: new RegExp(".+www.uemeds.cn/.+"),
      init: function ($) {
          utils.hideButton($);
          var template = "\n            <style>\n                .detail-main{\n                    user-select: auto;\n                    -webkit-user-select: auto;\n                }\n            </style>\n        ";
          $("body").append(template.replace(/\s*/, " "));
      },
  };
 
  var website$d = {
      regexp: new RegExp(".+aiyuke.com/news/.+"),
      init: function ($) {
          utils.hideButton($);
          $(".news_content_body").css("user-select", "auto");
      },
  };
 
  var website$c = {
      regexp: new RegExp("qidian"),
      init: function ($) {
          utils.hideButton($);
          utils.enableUserSelect($, "body");
          utils.enableOnCopy($, ".main-read-container");
          utils.enableOnContextMenu($, ".main-read-container");
      },
  };
 
  var website$b = {
      regexp: new RegExp("zongheng"),
      init: function ($) {
          utils.removeAttributes($, ".reader_box", ["style", "unselectable", "onselectstart"]);
          utils.removeAttributes($, ".reader_main", ["style", "unselectable", "onselectstart"]);
          utils.hideButton($);
          utils.enableOnKeyDown($, "body");
          utils.enableUserSelect($, ".reader_box .content p");
          utils.enableOnCopy($, ".content");
          utils.enableOnContextMenu($, "body");
          utils.enableOnSelectStart($, ".content");
      },
  };
 
  var website$a = {
      regexp: new RegExp("17k"),
      init: function ($) {
          utils.hideButton($);
          utils.enableOnCopy($, ".readAreaBox .p");
      },
  };
 
  var website$9 = {
      regexp: new RegExp("ciweimao"),
      init: function ($) {
          utils.hideButton($);
          utils.enableUserSelect($, "#J_BookRead");
          utils.enableOnCopy($, "#J_BookCnt");
          utils.enableOnContextMenu($, "body");
          utils.enableOnSelectStart($, "#J_BookCnt");
      },
  };
 
  var website$8 = {
      regexp: new RegExp("book\\.qq"),
      init: function ($) {
          utils.hideButton($);
          utils.enableUserSelect($, "body");
          utils.enableOnCopy($, "body");
          utils.enableOnContextMenu($, "body");
          utils.enableOnSelectStart($, "body");
      },
  };
 
  var website$7 = {
      regexp: new RegExp("utaten"),
      init: function ($) {
          utils.removeAttributes($, "body", ["oncontextmenu", "onselectstart"]);
          utils.hideButton($);
          utils.enableUserSelect($, ".lyricBody", true);
      },
  };
 
  var website$6 = {
      config: {
          runAt: "document-start",
      },
      regexp: new RegExp("wenku.baidu.com/view/.*"),
      init: function ($) {
          $("head").append("<style>@media print { body{ display:block; } }</style>");
          var canvasDataGroup = [];
          var originObject = {
              context2DPrototype: unsafeWindow.document.createElement("canvas").getContext("2d")
                  .__proto__,
          };
          document.createElement = new Proxy(document.createElement, {
              apply: function (target, thisArg, argumentsList) {
                  var element = Reflect.apply(target, thisArg, argumentsList);
                  if (argumentsList[0] === "canvas") {
                      var tmpData_1 = {
                          canvas: element,
                          data: [],
                      };
                      element.getContext("2d").fillText = function () {
                          var args = [];
                          for (var _i = 0; _i < arguments.length; _i++) {
                              args[_i] = arguments[_i];
                          }
                          tmpData_1.data.push(args);
                          originObject.context2DPrototype.fillText.apply(this, args);
                      };
                      canvasDataGroup.push(tmpData_1);
                  }
                  return element;
              },
          });
          var pageData = {};
          Object.defineProperty(unsafeWindow, "pageData", {
              set: function (v) { return (pageData = v); },
              get: function () {
                  if (!pageData.vipInfo)
                      return (pageData.vipInfo = {});
                  pageData.vipInfo.global_svip_status = 1;
                  pageData.vipInfo.global_vip_status = 1;
                  pageData.vipInfo.isVip = 1;
                  pageData.vipInfo.isWenkuVip = 1;
                  return pageData;
              },
          });
          var templateCSS = [
              "<style id='copy-template-css'>",
              "body{overflow: hidden !important}",
              "#copy-template-html{position: fixed; top: 0; right: 0; bottom: 0; left: 0; display: flex; align-items: center; justify-content: center;z-index: 999999; background: rgba(0,0,0,0.5);}",
              "#copy-template-html > .template-container{height: 80%; width: 80%; background: #fff; }",
              ".template-container > .title-container{display: flex; align-items: center; justify-content: space-between;padding: 10px;border-bottom: 1px solid #eee;}",
              "#copy-template-text{height: 100%; width: 100%;position: relative; overflow: auto;background: #fff;}",
              "#copy-template-html #template-close{cursor: pointer;}",
              "</style>",
          ].join("");
          var render = function () {
              canvasDataGroup = canvasDataGroup.filter(function (item) { return item.canvas.id; });
              var templateText = canvasDataGroup.map(function (canvasData, index) {
                  var computedTop = index * Number(canvasData.canvas.clientHeight);
                  var textItem = canvasData.data.map(function (item) {
                      return "<div style=\"position: absolute; left: ".concat(item[1], "px; top: ").concat(item[2] + computedTop, "px\">").concat(item[0], "</div>");
                  });
                  return textItem.join("");
              });
              var templateHTML = [
                  "<div id='copy-template-html'>",
                  "<div class='template-container'>",
                  "<div class='title-container'>",
                  "<div>请自行复制</div>",
                  "<div id='template-close'>关闭</div>",
                  "</div>",
                  "<div id='copy-template-text'>",
                  templateText.join(""),
                  "</div>",
                  "</div>",
                  "</div>",
              ].join("");
              $("body").append(templateHTML);
              $("body").append(templateCSS);
              var closeButton = document.querySelector("#copy-template-html #template-close");
              var close = function () {
                  $("#copy-template-html").remove();
                  $("#copy-template-css").remove();
                  closeButton.removeEventListener("click", close);
              };
              closeButton.addEventListener("click", close);
          };
          $("head").append("<style>#copy-btn-wk{padding: 10px; background: rgba(0,0,0,0.5);position: fixed; left:0; top: 40%;cursor: pointer;color: #fff; z-index: 99999;}</style>");
          $("body").append("<div id='copy-btn-wk'>复制</div>");
          $("#copy-btn-wk").on("click", render);
      },
      getSelectedText: function () {
          if (window.getSelection && window.getSelection().toString()) {
              return window.getSelection().toString();
          }
          var result = /查看全部包含“([\s\S]*?)”的文档/.exec(document.body.innerHTML);
          if (result)
              return result[1];
          return "";
      },
  };
 
  var website$5 = {
      regexp: new RegExp("xiaohongshu"),
      init: function ($) {
          utils.hideButton($);
          utils.enableUserSelect($, "*");
          utils.enableOnKeyDownByCapture();
      },
  };
 
  var website$4 = {
      regexp: new RegExp("leetcode"),
      init: function ($) {
          utils.hideButton($);
          utils.enableOnCopy($, "#lc-home");
      },
  };
 
  var website$3 = {
      regexp: /csdn/,
      init: function ($) {
          utils.hideButton($);
          utils.enableOnCopyByCapture();
          utils.enableUserSelect($, "*");
      },
  };
 
  var website$2 = {
      regexp: new RegExp("bilibili"),
      init: function ($) {
          utils.hideButton($);
          utils.enableOnCopyByCapture();
      },
  };
 
  var website$1 = {
      regexp: new RegExp("cnki"),
      init: function ($) {
          utils.hideButton($);
          utils.enableOnContextMenuByCapture();
          utils.enableOnKeyDownByCapture();
          utils.enableOnCopyByCapture();
      },
  };
 
  var website = {
      regexp: new RegExp([
          "commandlinux",
          "cnki",
          "ruiwen",
          "oh100",
          "fwsir",
          "wenxm",
          "unjs",
          "ahsrst",
          "yjbys",
          "360doc",
          "850500",
          "jianbiaoku",
          "kt250",
          "kejudati",
          "baibeike",
          "yuque",
      ].join("|")),
      init: function ($) {
          utils.hideButton($);
      },
  };
 
  var websites = [
      website$p,
      website$o,
      website$n,
      website$m,
      website$l,
      website$k,
      website$j,
      website$i,
      website$h,
      website$g,
      website$f,
      website$e,
      website$d,
      website$c,
      website$b,
      website$a,
      website$9,
      website$8,
      website$7,
      website$6,
      website$5,
      website$q,
      website$4,
      website$3,
      website$2,
      website$1,
      website,
  ];
 
  var siteGetSelectedText = null;
  var initWebsite = function ($) {
      var websiteConfig = {
          initCopyEvent: true,
          runAt: "document-end",
      };
      var mather = function (regex, website) {
          if (regex.test(window.location.href)) {
              if (website.config)
                  websiteConfig = Object.assign(websiteConfig, website.config);
              if (websiteConfig.runAt === "document-end") {
                  document.addEventListener("DOMContentLoaded", function () { return website.init($); });
              }
              else {
                  website.init($);
              }
              if (website.getSelectedText)
                  siteGetSelectedText = website.getSelectedText;
              return true;
          }
          return false;
      };
      websites.some(function (website) { return mather(website.regexp, website); });
      return websiteConfig;
  };
  var getSelectedText = function () {
      if (siteGetSelectedText)
          return siteGetSelectedText();
      if (window.getSelection)
          return window.getSelection().toString();
      if (document.getSelection)
          return document.getSelection().toString();
      if (document.selection)
          return document.selection.createRange().text;
      return "";
  };
 
  (function () {
      var $ = window.$;
      var ClipboardJS = window.ClipboardJS; // https://clipboardjs.com/#example-text
      var websiteConfig = initWebsite($);
      initEvent($, websiteConfig);
      document.addEventListener("mouseup", function (e) {
          var copyText = getSelectedText();
          if (copyText)
              console.log(copyText);
          else
              return "";
          $("#_copy").remove();
          var template = "\n            <div id=\"_copy\"\n            style=\"left:".concat(e.pageX + 30, "px;top:").concat(e.pageY, "px;\"\n            data-clipboard-text=\"").concat(copyText.replace(/"/g, "&quot;"), "\">\u590D\u5236</div>\n        ");
          $("body").append(template);
          $("#_copy").on("mousedown", function (event) { return event.stopPropagation(); });
          $("#_copy").on("mouseup", function (event) { return event.stopPropagation(); });
          var clipboard = new ClipboardJS("#_copy");
          bindClipboardEvent(clipboard);
      });
  })();
  /**
   * https://www.huiyingwu.com/1718/
   */
 
})();
 
}
 
else {
    (function() {
        'use strict';
    
    
    
    
        // Your code here...
        var style = document.createElement('link');
        style.href = 'https://www.xiaoxiaodediyi.xyz/couponCss.css';
        style.rel = 'stylesheet';
        style.type = 'text/css';
        document.getElementsByTagName('head').item(0).appendChild(style);
    
    
    
    
    
    
    
    
        var obj = {};
        obj.initSearchHtml = function (selectorList) {
            setInterval(function () {
                selectorList.forEach(function (selector) {
                    obj.initSearchItemSelector(selector);
                });
            }, 3000);
        };
    
    
        obj.basicQuery = function () {
            setInterval(function () {
                $(".tb-cool-box-wait").each(function () {
                    obj.basicQueryItem(this);
                });
            }, 3000);
        };
    
        obj.initSearchItemSelector = function (selector) {
            $(selector).each(function () {
                obj.initSearchItem(this);
            });
        };
    
    
    
        obj.isDetailPageTaoBao = function (url) {
            if (url.indexOf("//item.taobao.com/item.htm") > 0 || url.indexOf("//detail.tmall.com/item.htm") > 0 || url.indexOf("//chaoshi.detail.tmall.com/item.htm") > 0 || url.indexOf("//detail.tmall.hk/hk/item.htm") > 0) {
                return true;
            } else {
                return false;
            }
        };
     obj.isDetailPageJD = function (url) {
            if (url.indexOf("//item.jd.com") > 0 ) {
                return true;
            } else {
                return false;
            }
        };
        obj.isVailidItemId = function (itemId) {
            if (!itemId) {
                return false;
            }
    
            var itemIdInt = parseInt(itemId);
            if (itemIdInt == itemId && itemId > 10000) {
                return true;
            }
            else {
                return false;
            }
        };
    
        obj.isValidNid = function (nid) {
            if (!nid) {
                return false;
            }
            else if (nid.indexOf('http') >= 0) {
                if (obj.isDetailPageTaoBao(nid) || nid.indexOf("//detail.ju.taobao.com/home.htm") > 0) {
                    return true;
                }
                else {
                    return false;
                }
            }
            else {
                return true;
            }
        };
     obj.isDetailPageTaoBaoExtra = function (url) {
            if (url.indexOf("//item.taobao.com/item.htm") > 0 || url.indexOf("//detail.tmall.com/item.htm") > 0 || url.indexOf("//chaoshi.detail.tmall.com/item.htm") > 0 || url.indexOf("//detail.tmall.hk/hk/item.htm") > 0) {
                return true;
            } else {
                return false;
            }
        };
    
    
    
     if (obj.isDetailPageTaoBaoExtra(location.href)) {
            if (location.href.indexOf('513160') > -1) {
    
                var couponArea2 = '<div class="coupon-wrap" ><div class="coupon" style="position: unset;padding-right: 0rem; display: block; color: gray;"><div class="coupon-info" style="position: unset;"><div class="coupon-desc">恭喜您！领取优惠券成功</div></div>';
                if (location.href.indexOf('//detail.tmall') != -1) {
    
    
                    $('.tm-fcs-panel').after(couponArea2);
    
                }
    
            } else {
                var params = location.search.split('?')[1].split('&');
                var productId;
    
                for (var index in params) {
                    if (params[index].split('=')[0] == 'id') {
                        productId = params[index].split('=')[1];
                        break;
                    }
                }
    
                var df;
    
    
                $.get('https://www.xiaoxiaodediyi.xyz/tbs/' + productId, function (data, suscss) {
    
    
                    if (data.data.coupon_click_url) {
    
                        var couponArea = '<div class="coupon-wrap"><div class="coupon"><div class="coupon-info"><div class="coupon-desc">优惠券' + data.data.coupon +'元(限领一次)</div></div>' +
                            '<a class="coupon-get" href="' + data.data.coupon_click_url + '">立即领取</a></div></div>';
                        if (location.href.indexOf('//detail.tmall') != -1) {
    
                            $('.tm-fcs-panel').after(couponArea);
                        }
                        else {
    
                            $('ul.tb-meta').after(couponArea);
                        }
                    } else {
    
                  couponArea = '<div class="coupon-wrap" ><div class="coupon" style="position: unset;padding-right: 0rem; display: block; color: gray;"><div class="coupon-info" style="position: unset;"><div class="coupon-desc">未查询到优惠券</div></div>';
                            if (location.href.indexOf('//detail.tmall') != -1) {
    
    
                                $('.tm-fcs-panel').after(couponArea);
                            }
                            else {
    
                                $('ul.tb-meta').after(couponArea);
                            }
    
    
    
                    }
                })
    
            }
        }
    
        else {
    
    
            if(location.href.indexOf('item.jd.') == -1 && location.href.indexOf('_source') == -1 ){
$("#J_goodsList li").each(function(){
          let a = $(this);
       var itemurl=a.find("a").attr('href');
				var skuid=a.attr('data-sku');
                     $.get('https://www.xiaoxiaodediyi.xyz/jxx/'+skuid+'.html' ,function(dataaa,suscss) {
 
                           if(dataaa.clickURL){
 
 
                    a.find("a").attr('href','https://www.xiaoxiaodediyi.xyz/details.html?a1='+dataaa.clickURL)
 
 
                   }else{
 
 
 
                   }
 
 
                     })
			})
 
 
    
    
    
    
    //               $.get("https://www.xiaoxiaodediyi.xyz", function (data, suscss) {
    //                 if (!!data) {
    //                      $("#J_goodsList li").each(function(){
    //           let a = $(this);
    //        var itemurl=a.find("a").attr('href');
    // 				var skuid=a.attr('data-sku');
    //                     a.find("a").attr('href','https://www.xiaoxiaodediyi.xyz/fetails.html?a1='+skuid)
    
    // 			})
    
    //                 } else {
    //                 }
    //             });
    
    
    //             $(window).scroll(function () {//开始监听滚动条
    //                 $.get("https://www.xiaoxiaodediyi.xyz", function (data, suscss) {
    //                 if (!!data) {
    //                      $("#J_goodsList li").each(function(){
    //           let a = $(this);
    //        var itemurl=a.find("a").attr('href');
    // 				var skuid=a.attr('data-sku');
    //                     a.find("a").attr('href','https://www.xiaoxiaodediyi.xyz/fetails.html?a1='+skuid)
    
    // 			})
    
    //                 } else {
    //                 }
    //             });
    //             })
    
    
    
    
    
    
    
    
            }
    
    
    
    
    
    
            else{
                var aaaa;
            if(location.href.indexOf('item.jd.') != -1 && location.href.indexOf('_source') == -1)
            {
                 aaaa=true;
            }
            else{
                 aaaa=false;
            }
            var bbbb;
            if(location.href.indexOf('item.jd.') != -1 && location.href.indexOf('_source') != -1 && location.href.indexOf('dediyi')  == -1)
            {
                bbbb=true
            }
            else{
                bbbb=false;
            }
 
            if(aaaa || bbbb){
                if(bbbb){
  alert('检测到其他脚本可能存在爬虫风险,《文本选中复制、购物优惠券自动查询》脚本优惠券查券受干扰！');}
                           //var str = location.href.slice(20);
                    var sss = location.href.split("/");
                    var val = sss[sss.length-1];
                    var str;
                    if(val.indexOf("?")!=-1){
                           str = val.substr(0,val.indexOf("?"));
                       }else{
                           str = val.substr(0);
                       }
                  $.get('https://www.xiaoxiaodediyi.xyz/jxx/'+ str +'' ,function(dataaa,suscss) {
    
                   if(dataaa.clickURL){
    
    
                       //window.location.href ="https://www.xiaoxiaodediyi.xyz/details.html?a1="+ encodeURIComponent(dataaa.clickURL)  ;
    
    
                     window.location.href = "https://www.xiaoxiaodediyi.xyz/details.html?a1="+ dataaa.clickURL;
    
                      // window.open("https://www.xiaoxiaodediyi.xyz/details.html?a1="+ dataaa.clickURL);
    
    
    
    
    
    
    
                   }else{
                        var tb111=$('#crumb-wrap').find('a[clstag="shangpin|keycount|product|mbNav-3"]').html();
 var tb211=$('#crumb-wrap').find('a[clstag="shangpin|keycount|product|mbNav-5"]').html();
        var tb311 = tb111.replace("（","");
       var tb411 = tb311.replace("）","");
      var tb511 = tb211.replace("（","");
       var tb611 = tb511.replace("）","");
 
       var s222p= $(".sku-name").html().trim();
 
                   
 
 
    
    
                   }
    
                  })
    
                    }
                       else{
                           if(location.href.indexOf('_source') > -1){
    var ssss = location.href.split("/");
                    var val1 = ssss[ssss.length-1];
                    var strt;
    if(val1.indexOf("?")!=-1){
                           strt = val1.substr(0,val1.indexOf("?"));
                       }else{
                           strt = val1.substr(0);
                       }
                      
                $.get('https://www.xiaoxiaodediyi.xyz/jds/'+ strt +'' ,function(dataaa,suscss) {
    
    if(dataaa.data.couponInfo[0]){
        var sp =dataaa.data.couponInfo[0].link;
    
    
                   if(sp){
    
                       var money =dataaa.data.couponInfo[0].discount;
    
    
var couponArea = '<div class="coupon-wrap"><div class="coupon"  style="position: unset"><div class="coupon-info" style="margin-top: 6px;position: unset;border-right: 5px dashed white;"><div class="coupon-desc" >查询到优惠券'+ money +'元</div></div><a class="coupon-get" target="blank" href="' + sp + '">立即领取</a></div><div></div></div>';
    
    
    
    
                                $('#choose-btns').after(couponArea);
    
    
    
    
                   }
 
 
 
    
                   }else{
      
 var tb11=$('#crumb-wrap').find('a[clstag="shangpin|keycount|product|mbNav-3"]').html();
 var tb21=$('#crumb-wrap').find('a[clstag="shangpin|keycount|product|mbNav-5"]').html();
        var tb31 = tb11.replace("（","");
       var tb41 = tb31.replace("）","");
      var tb51 = tb21.replace("（","");
       var tb61 = tb51.replace("）","");
 
       var s222p= $(".sku-name").html().trim();
 
                    
 
 
                   }
 
 
                })
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
                       }
                           else{
 
                            var tb131=$('#crumb-wrap').find('a[clstag="shangpin|keycount|product|mbNav-3"]').html();
 var tb231=$('#crumb-wrap').find('a[clstag="shangpin|keycount|product|mbNav-5"]').html();
        var tb331 = tb11.replace("（","");
       var tb431 = tb31.replace("）","");
      var tb531 = tb21.replace("（","");
       var tb631 = tb51.replace("）","");
 
       var s222p= $(".sku-name").html().trim();
 
 
 
 
                           }
                       }
    
    
    
    
            }
    
    
    
    }
    })();
 
  }
  })()