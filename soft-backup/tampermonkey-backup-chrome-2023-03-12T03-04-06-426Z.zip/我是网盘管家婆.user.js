// ==UserScript==
// @name         我是网盘管家婆
// @namespace    http://tampermonkey.net/
// @version      10.4.4.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @antifeature  tracking 若密码忘记，从云端查询，有异议请不要安装
// @author       管家婆
// @include      *://*/*
// @connect      baidu.com
// @connect      fryaisjx.lc-cn-n1-shared.com
// @connect      api.kinh.cc
// @grant        unsafeWindow
// @grant        GM_xmlhttpRequest
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @grant        GM_notification
// @grant        GM_setClipboard
// ==/UserScript==
