// ==UserScript==
// @name           知网PDF下载助手
// @version        3.7.10
// @author         Supernova
// @description    直接下载知网PDF格式论文; 下载博士论文目录; 批量下载文献
// @include        http*://*.cnki.net/*
// @include        http*://*.cnki.net.*/*
// @include        */DefaultResult/Index*
// @include        */defaultresult/index*
// @include        */KNS8/AdvSearch*
// @include        */detail.aspx*
// @include        */CatalogViewPage.aspx*
// @include        */Article/*
// @include        */kns/brief/*
// @include        */kns55/brief/*
// @include        */grid2008/brief/*
// @include        */detail/detail.aspx*
// @exclude        http://image.cnki.net/*
// @run-at         document-idle
// @icon           https://cnki.net/favicon.ico
// @grant          unsafeWindow
// @grant          GM_setClipboard
// @grant          GM_xmlhttpRequest
// @grant          GM_notification
// @license        MIT
// @namespace https://github.com/supernovaZhangJiaXing/Tampermonkey/
// ==/UserScript==

'use strict';
var $ = unsafeWindow.jQuery;

$(document).ready(function() {
    var myurl = window.location.href;
    var isDetailPage = myurl.match(/(article|detail\.aspx)/g) ? true: false; // 点进文献后的详情页

    if (isDetailPage === false) {
        // 对应普通检索和高级检索
        if (window.location.href.indexOf("kns8") != -1 || window.location.href.indexOf("KNS8") != -1){
            $(document).ajaxSuccess(function(event, xhr, settings) {
                if (settings.url.indexOf('/Brief/GetGridTableHtml') + 1) {
                    // 如果是国内版, 改成海外版
                    if (window.location.href.indexOf("chn.oversea") == -1) {
                        for (var i = 0; i < $('.fz14').length; i++) {
                            $('.fz14').eq(i).attr('href', "https://chn.oversea.cnki.net/kcms/detail/detail.aspx" + $('.fz14').eq(i).attr('href').replace('\/kns8\/Detail', ''));
                        }
                    }
                    // 修改下载按钮
                    var down_btns = $('.downloadlink');
                    for (i = 0; i < down_btns.length; i++) {
                        down_btns.eq(i).css('background-color', '#C7FFFF').mouseover(function(e){
                            this.title="CAJ下载";
                        });
                        var pdf_down_btn = down_btns.eq(i).clone().css('background-color', '#C7FFC7').mouseover(function(e){
                            this.title="PDF下载";
                        });
                        pdf_down_btn.attr('href', "https://chn.oversea.cnki.net" + pdf_down_btn.attr('href'))
                        down_btns.eq(i).after(pdf_down_btn);
                    }
                    // 在后面新增一个批量下载按钮, 功能为下载pdf格式论文
                    $('.bulkdownload.export').eq(0).after($('.bulkdownload.export').eq(0).clone().html($('.bulkdownload.export').eq(0).html().replace('下载', 'PDF'))
                                                          .removeClass('bulkdownload').click(function () { // 点击下载按钮后的行为
                        // 获取到勾选的文献, 下载其pdf版
                        for (var i = 0; i < $('input.cbItem').length; i++) {
                            if ($('input.cbItem').eq(i).attr('checked') == 'checked') { // 只针对勾选中的i
                                sleep(1000).then(
                                    window.open($('.downloadlink').eq(2 * i + 1).attr('href'))
                                );
                            }
                        }
                        $.filenameClear();
                    }).css('background-color', '#C7FFC7'));
                    $('.bulkdownload.export').eq(0).html($('.bulkdownload.export').eq(0).html().replace('下载', 'CAJ'))
                                                          .removeClass('bulkdownload').click(function () { // 点击下载按钮后的行为
                        // 获取到勾选的文献, 下载其caj版
                        for (var i = 0; i < $('input.cbItem').length; i++) {
                            if ($('input.cbItem').eq(i).attr('checked') == 'checked') { // 只针对勾选中的i
                                sleep(1000).then(
                                    window.open($('.downloadlink').eq(2 * i).attr('href'))
                                );
                            }
                        }
                        $.filenameClear();
                    }).css('background-color', '#C7FFFF');
                }
                $('th').eq(8).css('width', '14%');
            });
        }
    }
    else {
        // 只对"博硕论文"详情页做优化, 否则影响期刊页面的显示
        // 来自: https://greasyfork.org/zh-CN/scripts/371938
        if (location.search.match(/dbcode=C[DM][FM]D/i) || $('.btn-html').html() == undefined) {
            // 整本下载替换为CAJ下载
            $(".btn-dlcaj").first().html($(".btn-dlcaj").first().html().replace("CAJ整本", "CAJ")); // 正则不知为什么用不了了
            var pdf_url;
            var pdf_down;
            var content_url;
            if (myurl.indexOf('chn.oversea') != -1) { // 进入了海外版页面
                // 删除原始PDF下载按钮并获取pdf文件的url
                pdf_url = $(".btn-dlpdf").remove().find("a").attr("href");
                // 添加新的PDF下载
                pdf_down = $('<li class="btn-dlpdf"><a onclick="WriteKrsDownLog()" target="_blank" id="pdfDown" name="pdfDown" href=' + pdf_url + ' ><i></i>PDF下载</a></li>');
                $(".btn-dlcaj").first().after(pdf_down);
                // 从分章下载获取目录的URL
                if ($("#cajDown1").text().trim() == 'CAJ分章下载') {
                    content_url = $("#cajDown1").attr("href") || '?';
                    content_url = "https://chn.oversea.cnki.net/kcms/Detail/DownDetail.aspx" + content_url.match(/\?.*/)[0];
                    if (content_url.indexOf("&downtype=catalog") != -1) {
                        content_url = content_url + "&downtype=catalog";
                    }
                    GM_xmlhttpRequest({method: 'GET', url: content_url, onload: manage_contents});
                }
            } else { // 进入了国内版页面
                // $("#pdfDown").html($("#pdfDown").html().replace("分页下载", "PDF下载"));
                // GM_xmlhttpRequest({method: 'GET', url: "https://chn.oversea.cnki.net/KCMS/detail/detail.aspx" + window.location.href.match(/\?.*/)[0], onload: function (xhr) {
                //     $("#pdfDown").attr('href', "https://chn.oversea.cnki.net" + $("#pdfDown1", xhr.responseText).attr("href"));
                // }});
                // 从分章下载获取目录的URL
                if ($(".btn-dlcaj").eq(1).text().trim() == '分章下载') {
                    content_url = $(".btn-dlcaj").eq(1).find('a').attr("href") || '?';
                    content_url = "https://kns.cnki.net/kcms/Detail/DownDetail.aspx" + content_url.match(/\?.*/)[0];
                    if (content_url.indexOf("&downtype=catalog") != -1) {
                        content_url = content_url + "&downtype=catalog";
                    }
                    GM_xmlhttpRequest({method: 'GET', url: content_url, onload: manage_contents});
                }
            }
            // 右侧添加使用说明
            $(".operate-btn").append($('<li class="btn-phone"><a target="_blank" '
                                       + 'href="https://mp.weixin.qq.com/s?__biz=MzU5MTY4NDUzMg==&mid=2247484384'
                                       + '&idx=1&sn=6a135e824793d26b5bd8884b78c1f751&chksm=fe2a753bc95dfc2d3a5f6'
                                       + '383553fc369894c5021619c85bb7554583bdcb8c10624bf2a7097e1&token=462651491&lang=zh_CN#rd"><i></i>脚本说明</a></li>'));
            // 右侧底部添加工具下载(PdgContentEditor)
            $(".opts-down").eq(0).append($('<div class="fl info" style="font-size: 13px; border-left: 1px solid #ddd;"><p class="total-inform" style="margin-left: 3px">'
                                     + '<span><a href="https://pan.baidu.com/s/1VoJlEqPnPN8H6oklAZ0bGQ" target="_blank">点击下载目录合并软件及说明</a><br />提取码: y77f<br />下载PDF请前往知网海外版</span>'))
        }
        // 移除关于CAJ的信息
        $(".fl.info").find("div").remove();
    }
});

// https://stackoverflow.com/a/951057/7795128
function sleep(time) {
  return new Promise((resolve) => setTimeout(resolve, time));
}

function get_content(cnt_list){
    // 海外版下载目录的方法不行了, 改从分章下载转换
    var contents = "";
    cnt_list.children().each(function () {
        var cnt_item = $(this).find('a').text();
        var cnt_page = $(this).find('.page').text().split('-')[0];
        var prev_space_length = $(this).attr('class').split('-')[1] * 4;
        contents = contents + cnt_item.trim().replace(/&nbsp;/g, " ").padStart(prev_space_length + cnt_item.trim().length, ' ') + "\t" + cnt_page + "\r\n";
    })
    return contents;
}

// 来自: https://greasyfork.org/zh-CN/scripts/371938
function manage_contents(xhr) {
    var cnt_list = $(".ls-chapters", xhr.responseText);
    var contents = get_content(cnt_list); // 目录内容
    // 添加目录复制
    $('.btn-dlpdf').first().after($('<li class="btn-dlpdf"><a href="javascript:void(0);">目录复制</a></li>').click(function() {
        GM_setClipboard(contents); // 运用油猴脚本自带的复制函数
        GM_notification('目录已复制到剪贴板');
    }));
    // 添加目录下载
    $('.btn-dlpdf').first().after($('<li class="btn-dlcaj"><a>目录下载</a></li>').click(function() {
        var data = new Blob([contents],{type:"text/plain; charset=UTF-8"});
        $(this).find('a').attr("download", '目录_' + $('.wx-tit h1:first-child()').text().trim() + '.txt');
        $(this).find('a').attr("href", window.URL.createObjectURL(data));
        window.URL.revokeObjectURL(data);
    }));
}
