// ==UserScript==
// @name 抖音网页版优化
// @description 抖音网页版推荐、直播优化，网页全屏，全黑，自动按浏览器窗口调整大小
// @namespace https://space.bilibili.com/482343
// @author 古海沉舟
// @license 古海沉舟
// @version 1.8.1
// @match https://www.douyin.com/*
// @include https://www.douyin.com/recommend
// @include https://www.douyin.com/*
// @include https://www.douyin.com/?*
// @include https://www.douyin.com/follow
// @include https://live.douyin.com/*
// @require https://cdn.staticfile.org/jquery/1.12.4/jquery.min.js
// @run-at document-end
// @grant GM_setValue
// @grant GM_getValue
// @grant GM_addValueChangeListener
// @noframes
// ==/UserScript==

var lastindex=0;

function keydown(event) {
    //console.log(event.keyCode);
    if(event.keyCode == 109 || event.keyCode == 189){ // 按-或者小键盘-
        pagefullscreen();
    }
}
document.addEventListener('keydown', keydown, false);

var haspagefullscreen=0;
if (location.href.indexOf("https://www.douyin.com/follow")>-1){
    haspagefullscreen=1;
}
function pagefullscreen(){
    var is=0;
    //$(`#slidelist > div > div.swiper-wrapper > div.swiper-slide-active xg-icon.xgplayer-page-full-screen > div.xgplayer-icon`).click();
    $(`#sliderVideo xg-icon.xgplayer-page-full-screen > div.xgplayer-icon`).each(function(){
        haspagefullscreen=1;
        $(this).click();
        is=1;
        if (is){return}
        console.log("非推荐");
        $(`xg-controls xg-icon>div > div:nth-child(2)`).each(function(){
            if ($(this).parent().text().indexOf("网页全屏")<0)return;
            console.log("判断：",$(this).text(),"  ",$(this)[0]);
            haspagefullscreen=1;
            $(this).click();
        })
    })
     if (is){return}
    $(`div[data-e2e="living-container"] xg-icon>div>div`).each(function(){
        if ($(this).parent().text().indexOf("网页全屏")<0)return;
            console.log("判断：",$(this).text(),"  ",$(this)[0]);
            haspagefullscreen=1;
            $(this).click();
    })

}
var firstfullscreen=setInterval(function(){
    if (haspagefullscreen){
        clearInterval(firstfullscreen);
        return;
    }
    pagefullscreen();
},1000);

setInterval(function(){
    filtergift();
},1000);

function filtergift(){ //过滤直播礼物
    $(`div.webcast-chatroom___item span.Q7mln_nz`).each(function(){
        if ($(this).text().indexOf("送出了")>-1){
            console.log($(this).parent().parent().parent().parent().text().replace(/\n/g, " ").replace(/\s\s/g, " "));
            $(this).parent().parent().parent().parent().hide();
        }
    })
}
function addCSS(){
    let wdstyle = document.createElement('style');
    wdstyle.classList.add("optimize");
    wdstyle.innerHTML = `
div.gNyVUu_s, .OaNxZqFU img, .iRX47Q8q img { display: none!important }
.qdcce5kG .VFMR0HAe { background: #0000 !important }
.vLt8mbfQ .y8iJbHin .mMOxHVzv, .vLt8mbfQ .y8iJbHin .rrKCA47Q, div.webcast-chatroom, .BasEuG5Q ._QjzkgP3, .OaNxZqFU,.basicPlayer.xgplayer{ background: #000 !important }
.Npz7CPXj, div.webcast-chatroom .webcast-chatroom___input-container .webcast-chatroom___textarea, .CgAB9miy, .JTIGfG2P, .NQ38Bc0h .XcEg0PrM, .N_HNXA04:not(.dUiu6B8O) .iViO9oMI, .UKFpY5tW, .SxCiQ8ip .EDvjMGPs { background: #111 !important }
.N_HNXA04:not(.dUiu6B8O) .kQ2JnIMK .n9PPTk22, .N_HNXA04 .kQ2JnIMK, .iwzpXgQ3 .oJArD0aS, .xWPMYXKp .gOSlkVoB,.Exz5X5r1{ background: #222 !important }
div.JwGiJkkI, div.xgplayer-dynamic-bg, div.umOY7cDY, div.ruqvqPsH { display: none !important }
.L8o4Hyg1,.L8o4Hyg1 .LFbb1oon,.L8o4Hyg1 .R6NHkCAw .i4vdvOF5{ box-shadow: none !important; border-bottom: none !important; border-right: none !important; }

.pgQgzInF.hqONwptG .Jf1GlewW.Ox89VrU5, .ckEyweZa.AmXnh1GR .QICHGW7r.RosH2lNv, .SxCiQ8ip.V6Va18Np .EDvjMGPs.FKQqfehj { height: 100% !important; }
div.immersive-player-switch-on-hide-interaction-area, #video-info-wrap, xg-inner-controls.xg-inner-controls { opacity: 0.6 !important }
.xgplayer-playswitch .xgplayer-playswitch-tab { opacity: 0 !important }
div.xgplayer-playswitch-tab:hover, div.immersive-player-switch-on-hide-interaction-area:hover, #video-info-wrap:hover, xg-inner-controls.xg-inner-controls:hover { opacity: 1 !important }
`
    document.body.appendChild(wdstyle);
}
addCSS();