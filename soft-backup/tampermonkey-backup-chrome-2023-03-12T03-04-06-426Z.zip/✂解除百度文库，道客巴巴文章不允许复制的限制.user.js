// ==UserScript==
// @name         ✂解除百度文库，道客巴巴文章不允许复制的限制
// @version      1.2.2.1
// @author       liuyuan7328
// @namespace    https://greasyfork.org/zh-CN/users/702160
// @description This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @include      *

//               ↓ jQuery核心文件 ↓
//               ↓ jQueryUI核心文件 ↓

// @grant        unsafeWindow
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_deleteValue
// @grant        GM_listValues
// @include     *://wenku.baidu.com/view/*
// @include     *://www.51test.net/show/*
// @include     *://www.xuexi.la/*
// @include     *://www.xuexila.com/*
// @include     *://www.cspengbo.com/*
// @include     *://www.doc88.com/*
// @include     *://segmentfault.com/*
// @include     *://wk.baidu.com/view/*
// @include     *://leetcode-cn.com/problems/*
// @include     *://www.zhihu.com/*
// @include     *://z.30edu.com.cn/*
// @license     GPL License
// @connect     res.doc88.com
// @grant       unsafeWindow
// @grant       GM_xmlhttpRequest
// ==/UserScript==
