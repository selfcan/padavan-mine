// ==UserScript==
// @name         百度网盘直链极速下载助手（全新版本）
// @namespace    http://tampermonkey.net/
// @version      1.9.8
// @antifeature  membership  为防止接口被盗！该脚本需要输入验证码之后才能使用完整功能，感谢理解！如果脚本不能正常使用，可以通过微信公众号联系我！
// @description  【3月10日 50M/S继续奔放】目前全网最简单的唯一一款可用的百度网盘 免VIP会员、无视黑号的极速下载油猴脚本，下载速度基本可以跑满你的带宽！一共支持三种下载方式，同时支持Windows，Mac，Linux，Android等多平台，每一种都能给你一种恐怖如斯的下载速度体验！
// @match        https://pan.baidu.com/*
// @icon         https://pan.baidu.com/m-static/base/static/images/favicon.ico
// @require      https://cdn.staticfile.org/limonte-sweetalert2/11.1.9/sweetalert2.all.min.js
// @require      https://cdn.staticfile.org/jquery/3.6.0/jquery.min.js
// @require      https://cdn.jsdelivr.net/npm/crypto-js@4.1.1/crypto-js.min.js
// @match        *://pan.baidu.com/*
// @grant        GM_xmlhttpRequest
// @grant        GM_openInTab
// @grant        GM_addStyle
// @grant        GM_setClipboard
// @grant        unsafeWindow
// @connect      biubiu00.cn
// ==/UserScript==
 
 
const servers = [
 
    "http://biubiu00.cn"
];
 
 
mainTask();
async function mainTask() {
    GM_addStyle('#superDown,#copyIDM>span,#sendAria>span:hover{cursor:pointer;color:white!important}');
    await sleep(2000);
    $('#layoutMain div:has(span.g-new-create)>span.g-dropdown-button:first').before('<span style="background:red;color:white;font-size:14px;padding-left:10px;padding-right:10px;border:none" class="g-dropdown-button g-button  g-button-blue" id="superDown">极速下载助手</span>');
    $('#superDown').on('click', async e => {
        let file = getSelectedFile(),
            pwd = genRandomStr(4);
        if (!file)
            return;
        sToast('正在获取百度分享链接...', 2000);
        let surl = await getShortUrl(file.fs_id, pwd);
        if (!surl) {
            return sAlert('百度分享链接获取失败');
        }
        showDialog(surl, pwd, file.server_filename)
 
    });
}
 
function showDialog(surl, pwd, fileName) {
    let defaultPassCodeValue = "";
    if (localStorage.HUM_pass && (Date.now() - +localStorage.HUM_passTime) < 86400000) {
        defaultPassCodeValue = localStorage.HUM_pass;
    } else {
        localStorage.HUM_pass = "";
    }
    let html = `<h1 id="title">正在获取 ${fileName} 的直链</h1>
         <hr>
         <div class="body" style="width: 800px;height:560px;display:flex" scroll="no">
             <div class="left" style="flex:3">
                 <div class="content1" style="text-align:left">
                     <h3>下载地址8小时有效，请及时下载</h3>
                 </div>
                 <hr>
                 <div class="content2" style="text-align:left">
                     <span style="margin-bottom:20px">* 链接 ↓ ↓ ↓ ：</span>
                     <p id="copyIDM" style="margin-bottom:10px;margin-top:10px"></p>
                     <p id="sendAria" style="margin-bottom:20px;margin-top:10px"></p>
 
                 </div>
                 <hr />
                     <strong style="font-size:20px; font-weight: bold; color:#FF0000">一个问题：你用的是谷歌浏览器吗？</strong>
                     <div style="font-size:15px;font-weight:bolder;text-center:left;margin-top:15px">最近百度严控，将在每晚7点-8点间开放下载接口！</div><br>
                 <div class="content3" style="font-size:left;background:#DFFFDF;">
                     <div style="font-size:15px;font-weight:bolder;text-align:left;margin-top:15px">【方式1】IDM用户代理（UA）必须设置为：yunlinGS</div><br>
                     <a href="http://mp.weixin.qq.com/s?__biz=Mzg5MzY3NDMyMw==&mid=2247484126&idx=1&sn=961eea7d0b52fa8b9fd85deb2d684c5a&chksm=c02a74e2f75dfdf4bf8e72f923cf0cd69090303caf416ba5f073fa899a8236141a1620d1253d#rd" target="_blank">【IDM配置教程】</a><a href="https://wws.lanzoui.com/b0epv77ch" target="_blank">【下载地址】</a></div>
                 <div class="content3" style="font-size:left;background:#DFFFDF;">
                     <div style="font-size:15px;font-weight:bolder;text-align:left;margin-top:15px">【方式2】Aria2/Motrix 无需配置，请看下方使用教程</div><br>
                     <a href="http://mp.weixin.qq.com/s?__biz=Mzg5MzY3NDMyMw==&mid=100000326&idx=1&sn=b077e83a41b269d26ffe1ed38c4f7576&chksm=402a747a775dfd6c8b7c42c0f6aaa487f82e138859c070979220aa2cc5d43294ed50a4cac6d4#rd" target="_blank">【Aria2/Motrix使用教程】</a><a href="https://wws.lanzoui.com/b0epv77ch" target="_blank">【下载地址】</a></div><br>
                     <div class="content3" style="font-size:left;background:#FFF0AC;">
                     <p><strong style="font-size:25px; font-weight: bold; color:#ff0000">重点提示：</strong>
                     <div style="font-size:13px;font-weight:bolder;text-align:left;margin-top:13px">1.初次使用请扫码关注公众号【云林公社】，回复验证码</div><br>
                     <div style="font-size:13px;font-weight:bolder;text-align:left;margin-top:13px">2.将验证码输入右边输入框中，即可获取高速直链！</div><br>
                     <div style="font-size:8px; font-weight:bolder;text-align:left; color:#ff0000">提示：验证码仅为6位数字，只需要回复即可获得，不需要做任务也不需要其它，关注即可获取！</div></a>
                 </div>
             </div>
             <div class="right"
                 style="flex:3;display: flex;flex-direction: column;justify-content: center;align-items: center;width:95%">
                 <div class="r-content1" style="width:100%;padding-top:0px">
                     <p id="tip1"></p>
 
                     <input name="passCode" id="passCode"
                         value="${defaultPassCodeValue}"
                         style="width:96%;height:40px;margin-top:20px;font-size:15px;background:#d9d9d9;border:none;outline:none;color:black;border-radius:10px;padding-left:10px;box-sizing:border-box"
                         placeholder="请输入验证码" />
                     <input id="dlBtn"
                         class="swal2-confirm swal2-styled" style="width:96%;height:40px;margin-top:20px;font-size:15px"
                         type="button" value="点击获取直链"></input><br><br>
                     <p><strong style="font-size:15px; font-weight: bold; color:#ff0000">* 为防止接口被滥用，不定期更新验证码</strong><br><br>
                                        <img width="60%"
						src="https://user-images.githubusercontent.com/95022917/223619635-c6301de9-3a8d-4f53-86cf-23c5a327b097.jpg" /></div>
                     <a href="http://mp.weixin.qq.com/s?__biz=Mzg5MzY3NDMyMw==&mid=2247484082&idx=1&sn=ce440bf4b5df1d0e24eccb674a95c92b&chksm=c02a748ef75dfd981bf89dbc56311b310ef9797e7e6e4dd93647bcfd63443b288f32692a076e#rd">下载错误？点击这里查看解决办法！</a>
                 </div>
                 <div class="r-content2">
 
                 </div>
             </div>
         </div>`;
 
    Swal.fire({
        html,
        width: 900,
        allowOutsideClick: false,
        showCloseButton: true,
        showCancelButton: true,
        confirmButtonText: '好评',
        cancelButtonText: '关闭',
        reverseButtons: true
    }).then(r => {
        if (r.isConfirmed)
            GM_openInTab('https://greasyfork.org/zh-CN/scripts/436053-%E7%99%BE%E5%BA%A6%E7%BD%91%E7%9B%98%E7%9B%B4%E9%93%BE%E6%9E%81%E9%80%9F%E4%B8%8B%E8%BD%BD%E5%8A%A9%E6%89%8B-%E5%85%A8%E6%96%B0%E7%89%88%E6%9C%AC/feedback');
    });
 
    $('#dlBtn').off().on("click", function () {
        let passCode = $("#passCode").val();
        if (passCode) {
            if (passCode != localStorage.HUM_pass) {
                localStorage.HUM_pass = passCode;
                localStorage.HUM_passTime = Date.now();
            }
            requestLink(passCode)
            $("#tip1").html("！！！！！！正在获取链接，请稍等！！！！！！在某个时段你可能需要一分钟才能获取到下载链接");
        } else {
            alert("请输入验证码")
        }
    });
 
    function requestLink(passCode) {
        (async () => {
            let exception = null;
            for (const server of servers) {
                try {
                    let pstr = await getFileInfo(surl, pwd, passCode, server);
                    return await getLinkCommon(pstr, server);
                } catch (e) {
                    exception = e;
                    continue;
                }
            }
            throw exception;
        })().then(link => {
            $("#tip1").html("获取高速链接成功！！！");
            $("h1#title").html(`获取 ${fileName} 的高速直链成功`);
            $("p#copyIDM").html(`<span style="background:red;color:white;font-size:14px;padding-left:10px;padding-right:10px;border:none" class="g-dropdown-button g-button  g-button-blue">复制IDM链接到剪贴板</span>`)
            $('#copyIDM').off().on('click', e => {
                GM_setClipboard(link);
                Toast('已复制IDM链接到剪贴板');
            });
            $("p#sendAria").html(`<span style="background:red;color:white;font-size:14px;padding-left:10px;padding-right:10px;border:none" class="g-dropdown-button g-button  g-button-blue" >发送到Aria2或Motrix</span>`);
            $('#sendAria').off().on('click', e => showAriaDialog(link, fileName));
        }).catch(e => {
            $("h1#title").html(`获取 ${fileName} 的高速直链失败`)
            $("#tip1").html(`获取高速链接<span style="font-weight:800;color:red">失败！！！</span>,原因是${e}`)
        });
    }
 
}
 
function getShortUrl(fs_id, pwd) {
    return fetch(`https://pan.baidu.com/share/set?channel=chunlei&clienttype=0&web=1&channel=chunlei&web=1&app_id=250528&bdstoken=${unsafeWindow.locals.get('bdstoken')}&clienttype=0`, {
        "headers": {
            "accept": "*/*",
            "accept-language": "zh-CN,zh;q=0.9",
            "content-type": "text/plain;charset=UTF-8",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "none"
        },
        "referrerPolicy": "no-referrer-when-downgrade",
        "body": `fid_list=[${fs_id}]&schannel=4&channel_list=[]&period=1&pwd=` + pwd,
        "method": "POST",
        "mode": "cors",
        "credentials": "include"
    }).then(r => r.json()).then(r => r.shorturl.replace(/^.+\//, '')).catch(e => null);
}
 
function getSelectedFile() {
    let list = require("system-core:context/context.js").instanceForSystem.list.getSelected();
    if (list && list.length === 1) {
        if (list[0].isdir === 1) {
            return sAlert('不支持目录');
        }
        return list[0];
    }
    return sAlert('仅支持单个文件');
}
 
function getFileInfo(surl, pwd, passCode, server) {
    return new Promise((resolve, reject) => {
        GM_xmlhttpRequest({
            method: 'POST',
            data: `surl=${surl}&pwd=${pwd}&Password=` + passCode,
            url: server,
            headers: {
                "content-type": "application/x-www-form-urlencoded",
            },
            onload: res => {
                if (res.status != 200)
                    return reject(res);
                resolve(res.responseText);
            },
            onerror: err => reject(err)
        });
    }).then(r => {
        let m = r.match(/javascript:confirmdl\((.+)\);/);
        if (m) return m[1];
        return Promise.reject($(r).find('div.alert.alert-danger').text().trim() || `获取下载信息失败`);
    });
}
 
function getLinkCommon(pstr, server) {
    return new Promise((resolve, reject) => {
        GM_xmlhttpRequest({
            method: 'POST',
            data: getParam(pstr),
            url: server + "/?download",
            headers: {
                "content-type": "application/x-www-form-urlencoded",
            },
            onload: res => {
                if (res.status != 200)
                    return reject(res);
                resolve(res.responseText);
            },
            onerror: err => reject(err)
        });
    }).then(r => {
        let link = $(r).find('#https').attr('href');
        if (link)
            return link;
        return Promise.reject($(r).find('div.alert.alert-danger').text().trim() || '获取直链失败');
    });
}
 
 
function getParam(pstr) {
    function fetch_token(fs_id, timestamp, sign, randsk, share_id, uk, bdstoken, filesize) {
        let base64 = btoa(fs_id + sign + uk);
        let base642 = btoa("nbest" + base64 + fs_id + "Yuan_Tuo" + share_id + sign + base64 + "baiduwp-php-donate");
        let md5 = CryptoJS.MD5(base642 + timestamp + base64).toString()
        return md5;
    }
    function urlEncode(obj) {
        return Array.isArray(obj) ? obj.map(o => urlEncode(o)).join('&') : Object.keys(obj).map(key => key + '=' + obj[key]).join('&');
    }
    let arr = pstr.replaceAll("'", '').split(',');
    arr.push(fetch_token(...arr));
    return urlEncode(['fs_id', 'time', 'sign', 'randsk', 'share_id', 'uk', 'bdstoken', 'filesize', 'token'].reduce((t, v, i) => (t[v] = arr[i]) && t, {}));
}
 
function showAriaDialog(url, filename) {
    Swal.fire({
        title: '发送到 Aria2 Json-RPC',
        html: `<div style="width:95%;text-align:left;">
         <label>RPC地址:</label>
         <input id="wsurl" class="swal2-input" style="width:100%;margin:10px 0;" value="${localStorage.wsurl || ''}">
          <div style="width:100%;margin:10px 0;"><small style="text-align:left;">推送aria2默认配置:<b>ws://localhost:6800/jsonrpc</b><br>推送Motrix默认配置:<b>ws://localhost:16800/jsonrpc</b></small></div>
         <label>Token:</label>
         <input id="token" class="swal2-input" style="width:100%;margin:10px 0;" value="${localStorage.wsToken || ''}">
         <div style="width:100%;margin:10px 0;"><small style="text-align:left;">没有token的话，留空</small></div>
         </div>`,
        allowOutsideClick: false,
        showCloseButton: true,
        focusConfirm: false,
        confirmButtonText: '发送',
        showCancelButton: true,
        cancelButtonText: '取消',
        reverseButtons: true,
        preConfirm: () => {
            let wsurl = $('#wsurl').val();
            if (!wsurl) {
                Swal.showValidationMessage('RPC地址必填');
                return;
            }
        }
    }).then(r => r.isConfirmed && addUri(url, filename));
}
 
function addUri(url, filename) {
    var wsurl = localStorage.wsurl = $('#wsurl').val();
    var uris = [url.replace('https:', 'http:'), url];
    var token = localStorage.wsToken = $('#token').val();
 
    var options = {
        "max-connection-per-server": "16",
        "user-agent": "dayu_xiami"
    };
    if (filename != "") {
        options.out = filename;
    }
 
    let json = {
        "id": "baiduwp-php",
        "jsonrpc": '2.0',
        "method": 'aria2.addUri',
        "params": [uris, options],
    };
 
    if (token != "") {
        json.params.unshift("token:" + token);
    }
 
    let patt = /^wss?\:\/\/(((([A-Za-z0-9]+[A-Za-z0-9\-]+[A-Za-z0-9]+)|([A-Za-z0-9]+))(\.(([A-Za-z0-9]+[A-Za-z0-9\-]+[A-Za-z0-9]+)|([A-Za-z0-9]+)))*(\.[A-Za-z0-9]{2,10}))|(localhost)|((([01]?\d?\d)|(2[0-4]\d)|(25[0-5]))(\.([01]?\d?\d)|(2[0-4]\d)|(25[0-5])){3})|((\[[A-Za-z0-9:]{2,39}\])|([A-Za-z0-9:]{2,39})))(\:\d{1,5})?(\/.*)?$/;
    if (!patt.test(wsurl)) {
        Swal.fire('地址错误', 'WebSocket 地址不符合验证规则，请检查是否填写正确！', 'error');
        return;
    }
    var ws = new WebSocket(wsurl);
 
    ws.onerror = event => {
        console.log(event);
        Swal.fire('连接错误', 'Aria2 连接错误，请打开控制台查看详情！', 'error');
    };
    ws.onopen = () => {
        ws.send(JSON.stringify(json));
    }
 
    ws.onmessage = event => {
        console.log(event);
        let received_msg = JSON.parse(event.data);
        if (received_msg.error !== undefined) {
            if (received_msg.error.code === 1)
                Swal.fire('通过RPC连接失败', '请打开控制台查看详细错误信息，返回信息：' + received_msg.error.message, 'error');
        }
        switch (received_msg.method) {
            case "aria2.onDownloadStart":
                Swal.fire('Aria2 发送成功', 'Aria2 已经开始下载！' + filename, 'success');
 
                localStorage.setItem('aria2wsurl', wsurl); // add aria2 config to SessionStorage
                if (token != "" && token != null)
                    localStorage.setItem('aria2token', token);
                break;
 
            case "aria2.onDownloadError": ;
                Swal.fire('下载错误', 'Aria2 下载错误！', 'error');
                break;
 
            case "aria2.onDownloadComplete":
                Swal.fire('下载完成', 'Aria2 下载完成！', 'success');
                break;
 
            default:
                break;
        }
    };
}
 
 
function sleep(t) {
    return new Promise(resolve => setTimeout(resolve, t));
}
 
function sAlert(msg) {
    Swal.fire(msg);
    return null;
}
 
function sToast(text, timer = 1500) {
    Swal.fire({
        text,
        timer,
        showConfirmButton: false
    });
}
 
function genRandomStr(len) {
    let t = "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz123456789",
        l = t.length;
    return Array(len).fill().map((v, i) => t.charAt(Math.floor(Math.random() * l))).join('');
}
 
function Toast(msg, duration = 3000) {
    var m = document.createElement('div');
    m.innerHTML = msg;
    m.style.cssText = "max-width:60%;min-width: 150px;padding:0 14px;height: 40px;color: rgb(255, 255, 255);line-height: 40px;text-align: center;border-radius: 4px;position: fixed;top: 50%;left: 50%;transform: translate(-50%, -50%);z-index: 999999;background: rgba(0, 0, 0,.7);font-size: 16px;";
    document.body.appendChild(m);
    setTimeout(() => {
        var d = 0.5;
        m.style.webkitTransition = '-webkit-transform ' + d + 's ease-in, opacity ' + d + 's ease-in';
        m.style.opacity = '0';
        setTimeout(() => { document.body.removeChild(m) }, d * 1000);
    }, duration);
}