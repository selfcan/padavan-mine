// ==UserScript==
// @name         2022华医网学习助手
// @version      0.1
// @description  华医
// @author
// @include        http://*.91huayi.com/
// @grant        none
// @namespace https://greasyfork.org/users/666980
// @license      GPL
// ==/UserScript==
window.onload = function () {
  try {
    setInterval(() => {
      document.querySelector("video").playbackRate =6;
    }, 3 * 1000);
  } catch (error) {}
};
