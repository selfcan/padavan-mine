// ==UserScript==
// @name         ✨超多影视站点综合优化 移动&桌面端通用🎉
// @namespace    https://ayouth.xyz/
// @version      5.2.3
// @description  令人舒畅的联想预测，适配所有网站搜索框，给影视搜索提提速。FREEOK、LIBVIO、THEFREE、爱看电影网、厂长资源、大米星球、NO视频、低端影视、69美剧、在线之家、努努影院、VOFLIX网站去广告等综合优化，后续会接着扩展和更新。GreasyFork脚本主页和脚本菜单都有持续更新的影视站点推荐页的链接，不妨收藏一下🎄。
// @author       Ayouth
// @supportURL   https://ayouth.xyz/msgboard/
// @match        *://www.freeok.vip/*
// @match        *://libvio.fun/*
// @match        *://libvio.me/*
// @match        *://www.thefree.vip/*
// @match        *://www.ikandy.fun/*
// @match        *://www.ikandy1.fun/*
// @match        *://www.czspp.com/*
// @match        *://www.dmxq.me/*
// @match        *://www.novipnoad.com/*
// @match        *://ddys.tv/*
// @match        *://ddys2.me/*
// @match        *://www.69mj.com/*
// @match        *://zxzj.vip/*
// @match        *://www.nunuyy5.org/*
// @match        *://www.voflix.com/*
// @icon         https://ayouth.xyz/favicon2.ico
// @grant        GM_registerMenuCommand
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @grant        unsafeWindow
// @run-at       document-body
// ==/UserScript==

(function () {
    "use strict";
    //工具类
    class Tool { constructor() { this.services = [] } debounce(e, t, n = !1) { let o; return function (...i) { !o && n && e.apply(this, i), o && clearTimeout(o), o = setTimeout((() => e.apply(this, i)), t) } } throttle(e, t) { let n, o; return function (...i) { const r = (new Date).getTime(); if (o && clearTimeout(o), n) if (r - n >= t) n = r, e.apply(this, i); else { o = setTimeout((() => { n = (new Date).getTime(), e.apply(this, i) }), t - (r - n)) } else n = r, e.apply(this, i) } } delay(e, t, ...n) { return setTimeout(e, t, ...n) } tick(e, t, n, ...o) { let i; const r = () => { clearInterval(i) }, s = () => { e(r, ...o) }; return i = setInterval(s, t), !0 === n && s(), i } open(e, t = "请点击前往") { if (!1 === /macintosh|mac os x/i.test(window.navigator.userAgent)) window.open(e); else { if (null === this.q("style#Toolopen")) { const e = '#Topen:hover { background: #4d76f3; } @keyframes scale-in-center { 0% { transform: scale(0); opacity: 1; } 100% { transform: scale(1); opacity: 1; } } #Topen { font-family:Tahoma, Arial, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;letter-spacing:1px;font-weight:bold;animation: scale-in-center 0.5s cubic-bezier(0.250, 0.460, 0.450, 0.940) both; transition: 0.15s; font-size: 20px; display: block; background: #6589f2; color: #efefef; text-decoration: underline; box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.35); border-radius: 4px; margin: auto; width: fit-content; height: fit-content; z-index: 9999999; position: fixed; top: 0; left: 0; right: 0; bottom: 0; padding: 12px; display: flex; align-items: center; justify-content: center }'; this.injectStyle(e, "Toolopen") } this.qs("a#Topen").forEach((e => e.remove())); const n = document.createElement("a"); n.target = "_blank", n.href = e, n.id = "Topen", n.textContent = t, n.onclick = () => { n.remove() }, document.documentElement.appendChild(n) } return this } addService(e, t, n) { let o = this.services.length; const i = () => { this.removeService(o) }, r = new MutationObserver(((t, n) => { e(t, n, i) })); return r.observe(t, n), this.services.push(r), o } removeService(e) { return null !== this.services[e] && (this.services[e].disconnect(), this.services[e] = null), this } type(e, t) { return "string" == typeof t ? typeof e === t.trim().toLowerCase() : typeof e } ready(e, t = 0) { if ("function" === this.type(e)) { const n = o => { document.removeEventListener("DOMContentLoaded", n), this.delay(e, t, o) }; "loading" != document.readyState ? n(new Event("DOMContentLoaded")) : document.addEventListener("DOMContentLoaded", n) } return this } q(e) { try { return document.querySelector(e) } catch (e) { return null } } qs(e) { try { return [...document.querySelectorAll(e)] } catch (e) { return [] } } injectStyle(e, t) { const n = "string" == typeof t && this.q("#" + t.trim()) || document.createElement("style"); return n.innerHTML += e, "string" == typeof t && (n.id = t), n.isConnected || (document.head ? document.head.insertAdjacentElement("afterend", n) : document.body ? document.body.insertAdjacentElement("beforebegin", n) : document.documentElement.appendChild(n)), this } import(...e) { return Promise.all(e.map((e => new Promise(((t, n) => { const o = e.type || "script", i = e.attr || {}, r = document.createElement(o); Object.keys(i).forEach((e => r.setAttribute(e, i[e]))), (document.body || document.documentElement).appendChild(r), r.onload = e => t({ evt: e, resource: r }), r.onerror = e => n({ evt: e, resource: r }) }))))) } hide(e) { return e instanceof HTMLElement ? this.css(e, { display: "none" }, !0) : this.injectStyle(`${e} { display:none !important; }`, "Toolhide"), this } remove(e) { return this.qs(e).forEach((e => e.remove())), this } css(e, t, n) { let o = ""; if (!(e instanceof HTMLElement)) { if (t) o += "string" == typeof t ? `${e}{ ${t} ;}` : ` ${e}{` + Object.entries(t).map((([e, t]) => `${e}:${t} ${!1 !== n ? "!important" : ""};`)).join(" ") + "}"; else { const t = this.q(e); if (t) return window.getComputedStyle(t) } return this.injectStyle(o, "Toolcss"), this } if (!t) return window.getComputedStyle(e); Object.entries(t).forEach((([t, o]) => { e.style.setProperty(t, o, !1 !== n ? "important" : void 0) })) } on(e, t, n, o) { const i = []; "string" == typeof e ? i.push(...this.qs(e)) : i.push(e); const r = t.split(" ").filter((e => e.length > 0)); i.forEach((e => { r.forEach((t => { const i = () => { e.removeEventListener(t, r, o) }, r = e => { n(e, i) }; e.addEventListener(t, r, o) })) })) } test(e) { const t = (e = e || {}).host instanceof Array ? e.host : [e.host || window.location.host], n = e.path instanceof Array ? e.path : [e.path || window.location.pathname]; let o, i = (e, t) => e instanceof RegExp ? e.test(t) : t.indexOf(e) > -1, r = (e, t) => e instanceof RegExp ? e.test(t) : t === e; return o = e.strict ? t.every((e => r(e, location.host))) && n.every((e => r(e, location.pathname))) : t.some((e => i(e, location.host))) && n.some((e => i(e, location.pathname))), o && e.callback && e.callback(), o } var(e, t) { const n = window.unsafeWindow instanceof Window ? window.unsafeWindow : window; return void 0 === e ? n : void 0 === t ? n[e] : (n[e] = t, this) } } const T = new Tool, $log = { connector: " - ", levelColor: { error: "#f91b1b", warning: "#ffc107", success: "#4EE04E", info: "initial" }, getTimeString: () => new Date((new Date).getTime() + 60 * (new Date).getTimezoneOffset() * 1e3 + 288e5).toLocaleString(), print(e, t) { const n = this.levelColor[t], o = `%c${this.getTimeString()}${this.connector}%c${e}`; console.log(o, "color:#1ce8e8", "color:" + n) }, err(e) { this.print(e, "error") }, info(e) { this.print(e, "info") }, suc(e) { this.print(e, "success") }, warn(e) { this.print(e, "warning") } }, $browser = { env: (() => { const e = { webview: /\(.+wv\)/i.test(window.navigator.userAgent), android: /Android/i.test(window.navigator.userAgent), linux: /Linux/i.test(window.navigator.userAgent), ios: /ios/i.test(window.navigator.userAgent), macos: /macOS/i.test(window.navigator.userAgent), windows: /win|Windows/i.test(window.navigator.userAgent), iphone: /iPhone/i.test(window.navigator.userAgent), ipad: /iPad/i.test(window.navigator.userAgent), mobile: /(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i.test(window.navigator.userAgent), pc: !1 }; return e.pc = !e.mobile, e })(), platform: window.navigator.platform, language: window.navigator.language, Chinese: { traditional: ["zh-TW", "zh-HK", "zh-Hant", "zh-MO"].some((e => e.toLowerCase() === String(window.navigator.language).toLowerCase())), simplified: ["zh-CN", "zh-Hans", "zh-SG", "zh-MY"].some((e => e.toLowerCase() === String(window.navigator.language).toLowerCase())) } };
    class Predict { lastTimestamp = null; constructor(e = "baidu", t, i = "predictiveTypingCallback", s = null) { if (this.objectName = i, this.global = t || window, this.global[i] || (this.global[i] = {}), this.api = e, this.defaultCallback = s, this._initAPI(), !this._apiComponents[e]) throw new Error("illegal api " + e) } _initAPI() { this._apiComponents = { baidu: { argsHandler(...e) { return e[0].s }, urlCreater(e, t) { return "//suggestion.baidu.com/su?wd=" + e + "&cb=" + t } }, bing: { argsHandler(...e) { try { return e[0].AS.Results[0].Suggests.map(e => e.Txt) } catch (e) { return [] } }, urlCreater(e, t) { return "//sg1.api.bing.com/qsonhs.aspx?type=cb&q=" + e + "&cb=" + t } } } } _createWrapper(t, i, s) { const l = this._apiComponents[this.api].argsHandler; return (...e) => { this.lastTimestamp === s && i(t, l(...e)) } } _generateURL(e, t) { return this._apiComponents[this.api].urlCreater(e, t) } setCallback(e) { return this.defaultCallback = e, this } setAPI(e) { if (this.api = e, this._apiComponents[e]) return this; throw new Error("illegal api " + e) } typing(e, t) { this.defaultCallback && !t && (t = this.defaultCallback); var i = this.lastTimestamp = (new Date).getTime(), t = this._createWrapper(e, t, i); e = encodeURIComponent(e), this.global[this.objectName]["_" + i] = t; const s = document.createElement("script"); return s.async = !0, s.referrerPolicy = "no-referrer", s.src = this._generateURL(e, "window." + this.objectName + "._" + i), document.body.appendChild(s), s.onload = s.onabort = s.onerror = () => { s.remove() }, this } } class EasyPredict extends Predict { constructor(e, t = { global: window, api: "baidu", theme: "light", fillValue: void 0, submitCallback: void 0, zIndex: 2022, maxNum: 8, fontFamily: void 0, fontSize: void 0 }) { super(t.api || "baidu", t.global || window), this.el = "string" == typeof e ? document.querySelector(e) : e, this.fillValue = ("function" == typeof t.fillValue ? t : EasyPredict).fillValue, this.submitCallback = "function" == typeof t.submitCallback ? t.submitCallback : () => { }, this.fontFamily = t.fontFamily || "", this.fontSize = t.fontSize || "", this.zIndex = t.zIndex || 2022, this.theme = t.theme || "light", this.maxNum = t.maxNum || 8, this.enabled = !1, this.ul = EasyPredict.createListDOM(this.maxNum), this.ul.style.zIndex = this.zIndex, this.toggleTheme(this.theme), this.resultCount = 0, this.keyword = 0 } toggleTheme(e = "dark") { e = e.toLowerCase(); let t = ["dark"]; t.forEach(e => this.ul.classList.remove(e)), this.theme = e, !1 !== t.includes(e) && this.ul.classList.add(e) } static createListDOM(t = 8) { if (!document.querySelector("style#easy-predict-by-ayouth")) { let e = document.createElement("style"); e.innerHTML = `ul.easy-predict-by-ayouth { transition: 50ms; display: block; position: absolute; z-index: 2022; list-style: none; box-sizing: border-box; padding: 0; margin: 0; letter-spacing: 1px; overflow: hidden; border-radius: 3px; font-weight: 400; box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.32); font-size: 16px; width: 200px; font-family: Tahoma, Arial, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif; --bg-color: #fafafa; --color: #222325; background-color: var(--bg-color, #efefef); color: var(--color, #18191C); --hover-bg-color: #e6e6e6; --high-light-color: #f25d8e; } ul.easy-predict-by-ayouth.dark { --high-light-color: #fe5f94; --hover-bg-color: rgba(212, 212, 212, 0.25); --bg-color: rgba(0, 0, 0, 0.5); --color: #eeeeee; box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.55); } ul.easy-predict-by-ayouth li { transition: 0.15s; display: block; width: auto; cursor: default; padding: 6px; margin: 0; color: inherit; background-color: inherit; font-family: inherit; position: relative; z-index: 1; } ul.easy-predict-by-ayouth li.last::before, ul.easy-predict-by-ayouth li:last-child::before { content: 'Ayouth'; z-index: -1; font-size: 12px; padding: 1.15px; background-color: rgba(236, 118, 105, 0.75); color: rgba(255, 255, 255, 0.9); position: absolute; display: block; bottom: 0; right: 0; } ul.easy-predict-by-ayouth li .high-light { color: var(--high-light-color); font-size: inherit; font-family: inherit; font-style: normal; } ul.easy-predict-by-ayouth li.hover { background-color: var(--hover-bg-color, #d3d3d3); }`, (document.head || document.body).appendChild(e) } let i = document.createElement("ul"); i.className = "easy-predict-by-ayouth"; for (let e = 0; e < t; e++)i.appendChild(document.createElement("li")); return i } static fillValue(e, t) { e.value = t } enable() { this.enabled || (!(this.ul.style.display = "none") === this.ul.isConnected && document.body.appendChild(this.ul), clearInterval(this.tid), this.tid = setInterval(() => { this.followStyle() }, 50), this.followStyle(), this.bindEvents(), document.activeElement === this.el && document.hasFocus() && "" !== this.el.value.trim() && this.events.input(), this.enabled = !0) } disable() { this.enabled && (this.ul.style.display = "none", clearInterval(this.tid), this.unbindEvents(), this.enabled = !1) } render(i, s, e) { i.innerHTML = "", -1 === e.indexOf(s) ? i.textContent = e : e.split(s).forEach((e, t) => { if (0 < t) { let e = document.createElement("span"); e.className = "high-light", e.textContent = s, i.appendChild(e) } "" !== e && i.append(e) }) } bindEvents() { if (!this.events) { this.events = {}, this.liIndex = -1, this.setCallback((i, s) => { let l = (s = s.slice(0, this.maxNum)).length; 0 < l && i === this.el.value ? (this.resultCount = l, this.keyword = i, this.ul.style.display = "block", this.ul.querySelectorAll("li").forEach((e, t) => { t < l ? (e.dataset.text = s[t], this.render(e, i, s[t]), e.style.display = "block") : e.style.display = "none", t == l - 1 ? e.classList.add("last") : e.classList.remove("last") })) : this.ul.style.display = "none" }); let i = (t, i = !1) => { let s = [...this.ul.querySelectorAll("li")]; if (s.forEach(e => e.classList.remove("hover")), 0 <= t) { let e = s[t]; e.classList.add("hover"), i && this.fillValue(this.el, e.dataset.text) } else -1 === t && i && this.fillValue(this.el, this.keyword) }, s = !1; this.events.input = () => { "" === this.el.value.trim() ? this.ul.style.display = "none" : (this.liIndex = -1, i(this.liIndex), this.typing(this.el.value)) }, this.events.mouseover = e => { let t = [...this.ul.querySelectorAll("li")]; e = t.indexOf(e.target); this.liIndex = e, i(this.liIndex) }, this.events.mouseleave = () => { this.liIndex = -1, i(-1) }, this.events.compositionstart = () => { s = !0 }, this.events.compositionend = () => { s = !1 }, this.events.keydown = e => { var t = e.code || e.key; if ("Enter" === t && 0 < this.liIndex) this.submitCallback(this.el.value); else if (!s) { if (0 == ["ArrowDown", "ArrowUp"].includes(t)) return !1; e.preventDefault(), "none" !== this.ul.style.display && (this.liIndex = "ArrowDown" === t ? this.liIndex >= this.resultCount - 1 ? -1 : this.liIndex + 1 : this.liIndex <= -1 ? this.resultCount - 1 : this.liIndex - 1, i(this.liIndex, !0)) } }, this.events.click = e => { e.target !== this.el && (this.ul.style.display = "none") }, this.events.focus = () => { "" !== this.el.value.trim() && this.events.input() }, this.events.ulclick = e => { let t = [...document.querySelectorAll("li")]; t.includes(e.target) && (this.fillValue(this.el, e.target.dataset.text), this.submitCallback(this.el.value)) } } this.ul.addEventListener("click", this.events.ulclick), this.ul.addEventListener("mouseover", this.events.mouseover), this.ul.addEventListener("mouseleave", this.events.mouseleave), this.el.addEventListener("input", this.events.input), this.el.addEventListener("compositionstart", this.events.compositionstart), this.el.addEventListener("compositionend", this.events.compositionend), this.el.addEventListener("focus", this.events.focus), this.el.addEventListener("keydown", this.events.keydown), this.global.document.addEventListener("click", this.events.click) } unbindEvents() { this.events && (this.liIndex = -1, this.ul.removeEventListener("click", this.events.ulclick), this.ul.removeEventListener("mouseover", this.events.mouseover), this.ul.removeEventListener("mouseleave", this.events.mouseleave), this.el.removeEventListener("input", this.events.input), this.el.removeEventListener("compositionstart", this.events.compositionstart), this.el.removeEventListener("compositionend", this.events.compositionend), this.el.removeEventListener("focus", this.events.focus), this.el.removeEventListener("keydown", this.events.keydown), this.global.document.removeEventListener("click", this.events.click)) } static getDOMLocation(e) { return e.getBoundingClientRect() } followStyle() { var e = EasyPredict.getDOMLocation(this.el), e = (this.ul.style.width = e.width + "px", this.ul.style.fontSize = this.fontSize || window.getComputedStyle(this.el).fontSize, this.ul.style.fontFamily = this.fontFamily || "", this.ul.style.top = e.top + e.height + window.scrollY + 2 + "px", this.ul.style.left = e.left + "px", window.getComputedStyle(this.ul)); "hidden" === e.visibility || "none" === e.display ? this.ul.style.display = "none" : this.ul.style.display = "block" } }
    //注册菜单函数
    function register() {
        if (window.top !== window) {
            return;
        }
        if ("undefined" === typeof GM_registerMenuCommand || "undefined" === typeof GM_getValue || "undefined" === typeof GM_setValue) {
            $log.err("当前不处于脚本管理器环境，停止菜单注册");
            return;
        }
        if (!GM_getValue('config')) {
            GM_setValue("config", JSON.stringify(config))
        } else {
            let savedConfig = JSON.parse(GM_getValue("config"));
            //维护和更新已保存的config
            if (T.type(savedConfig.option, "object")) {
                Object.keys(config.option).forEach(key => {
                    if (!T.type(savedConfig.option[key], "undefined")) {
                        config.option[key] = savedConfig.option[key];
                    }
                })
            }
            GM_setValue("config", JSON.stringify(config));
        };
        // 值取true或false的菜单
        const menu = {
            removeNotification: "移除通知",
            predictiveSearch: "联想词预测",
            darkMode: "深色预测UI",
            useBing: "使用Bing接口",
        };
        let commands = [];
        Object.keys(menu).forEach(e => {
            let desc = (config.option[e] ? "✅ " : "❌ ") + menu[e];
            let opposite = !config.option[e];
            let callback = () => {
                config.option[e] = opposite;
                GM_setValue("config", JSON.stringify(config));
                window.location.reload();
            }
            commands.push([desc, callback]);
        });
        for (let command of commands) {
            GM_registerMenuCommand(command[0], command[1]);
        }
        GM_registerMenuCommand("✨ 影视站点推荐", function () {
            T.open("https://ayouth.xyz/ayouth/video.html");
        });
        GM_registerMenuCommand("💬 给作者留言", function () {
            T.open("https://ayouth.xyz/msgboard");
        });

    }
    function startPredict(sel, opt = {}) {
        T.ready(() => {
            let ep;
            const execute = () => {
                let s = T.q(sel);
                if (!s) { return; }
                s.setAttribute("autocomplete", "off");
                ep = new EasyPredict(s, Object.assign({
                    api: config.option.useBing ? "bing" : "baidu",
                    fontSize: "14px",
                    theme: config.option.darkMode ? "dark" : "light",
                    global: T.var()
                }, opt));
                ep.enable();
            };
            // 初次执行
            execute();
            // 防止无感刷新
            T.addService(T.throttle(() => {
                // 判断url改变
                if (ep && ep.el.isConnected === false) {
                    ep.disable();
                    $log.suc("检测到无感刷新，已重新执行联想预测初始化")
                    execute();
                }
            }, 600), document.body, { subtree: true, childList: true });
        })
    }
    var websites = {
        "FREEOK": {
            domain: "www.freeok.vip",
            strict: false,
            onlyRunOnTop: true,
            mobile() { },
            pc() { },
            common() {
                // 预测
                if (config.option.predictiveSearch) {
                    startPredict(".search-input", {
                        submitCallback() {
                            let btn = T.q("#searchbutton");
                            btn && btn.click();
                        }
                    })
                }
                if (config.option.removeNotification) {
                    document.cookie = "showBtn=true;path=/;expires=Fri, 31 Dec 2222 23:59:59 GMT";
                    $log.suc("已移除通知");
                }
                // 修复深浅色模式记录长久保存
                T.ready(() => {
                    T.on(".fixedGroup-item:first-child", "click", () => {
                        setTimeout(() => {
                            document.cookie = `mx_style=${document.cookie.indexOf("mx_style=black") > -1 ? "black" : "white"};path=/;expires=Fri, 31 Dec 2222 23:59:59 GMT`;
                        }, 10);
                    });
                });
            }
        },
        "LIBVIO": {
            domain: ["libvio.fun", "libvio.me"],
            strict: false,
            onlyRunOnTop: true,
            mobile() { },
            pc() { },
            common() {
                //广告
                T.hide("[class*='advertise'],#HMRichBox,header ~ .container >.t-img-box,body >.inner-advertise");
                $log.suc("已移除广告");
                // sessionStorage置值方法有延迟影响观感
                // sessionStorage.setItem("isShowP", "hide");
                if (T.test({ path: "/type/" })) {
                    T.hide("div.container > .t-img-box:first-child");
                }
                // 预测
                if (config.option.predictiveSearch) {
                    startPredict("input#wd", {
                        submitCallback() {
                            let btn = T.q("#searchbutton");
                            btn && btn.click();
                        }
                    })
                }
                if (config.option.removeNotification) {
                    sessionStorage.setItem("note", "1");
                    $log.suc("已移除通知");
                }
                if (T.test({ path: "/play/" })) {
                    T.hide("body > div:nth-child(3) > div.t-img-box");
                    $log.suc("已移除广告");
                }
            }
        },
        "THEFREE": {
            domain: "www.thefree.vip",
            strict: false,
            onlyRunOnTop: true,
            mobile() { },
            pc() { },
            common() {
                if (config.option.removeNotification) {
                    document.cookie = "showBtn=true;path=/;expires=Fri, 31 Dec 2222 23:59:59 GMT";
                    $log.suc("已移除通知");
                }
                // 修复深浅色模式记录长久保存
                T.ready(() => {
                    T.on("div.fixedGroup-item:nth-child(3)", "click", () => {
                        setTimeout(() => {
                            document.cookie = `mx_style=${document.cookie.indexOf("mx_style=black") > -1 ? "black" : "white"};path=/;expires=Fri, 31 Dec 2222 23:59:59 GMT`;
                        }, 10);
                    });
                });
            }
        },
        "爱看电影网": {
            domain: ["www.ikandy1.fun", "www.ikandy.fun"],
            strict: false,
            onlyRunOnTop: true,
            mobile() { },
            pc() { },
            common() {
                // 广告
                T.hide("div[style*='top'][style*='fixed']:not([id],[class])");
                // 预测
                if (config.option.predictiveSearch) {
                    startPredict("input#wd", {
                        submitCallback() {
                            let btn = T.q("#searchbutton");
                            btn && btn.click();
                        }
                    })
                }
                if (config.option.removeNotification) {
                    T.hide("#ik");
                    T.hide(".stui-pannel_hd[style*='margin-top']");
                    T.css(".marquee_outer", { opacity: 0 });
                    T.hide(".stui-pannel_hd img[src*='GMCoOSYG7I4lAAGo5AGdHEDm.jpg']");
                    $log.suc("已移除通知");
                }
            }
        },

        "厂长资源": {
            domain: "www.czspp.com",
            strict: false,
            onlyRunOnTop: true,
            mobile() { },
            pc() { },
            common() {
                //广告
                T.hide(".ad,[class*='ads']");
                $log.suc("已移除广告");
                // 预测
                if (config.option.predictiveSearch) {
                    startPredict("#sosuobox input#s", {
                        submitCallback() {
                            let btn = T.q("#sosuobox button[type='submit']");
                            btn && btn.click();
                        }
                    })
                }
                if (config.option.removeNotification) {
                    document.cookie = "myannoun=1;path=/;expires=Fri, 31 Dec 2222 23:59:59 GMT"
                    $log.suc("已移除通知");
                }
            }
        },
        "大米星球": {
            domain: "www.dmxq.me",
            strict: false,
            onlyRunOnTop: true,
            mobile() {
            },
            pc() {
            },
            common() {
                // 预测
                if (config.option.predictiveSearch) {
                    startPredict("input.search-input", {
                        submitCallback() {
                            let btn = T.q("#searchbutton");
                            btn && btn.click();
                        }
                    })
                }
                T.hide("div[id][class*='is_'][style*='margin-bottom:12px;']");
                T.hide("div[id][class*='is_'][style*='margin:']");
                $log.suc("已移除广告");
                if (config.option.removeNotification) {
                    document.cookie = "showBtn=true;path=/;expires=Fri, 31 Dec 2222 23:59:59 GMT";
                    $log.suc("已移除通知");
                }
            }
        },
        "NO视频": {
            domain: "www.novipnoad.com",
            strict: false,
            onlyRunOnTop: true,
            mobile() { },
            pc() { },
            common() {
                // 预测
                if (config.option.predictiveSearch) {
                    startPredict("input#s", {
                        submitCallback() {
                            let btn = T.q("input#searchsubmit");
                            btn && btn.click();
                        }
                    });
                    startPredict("#headline > div > div > div.socia1-links.col-md-6.col-sm-6 > div > div > form > div > input", {
                        submitCallback() {
                            let btn = T.q("#headline > div > div > div.socia1-links.col-md-6.col-sm-6 > div > div > form > div > span > button");
                            btn && btn.click();
                        }
                    })
                }
                T.hide(".ad.ad_single_title,.bg-ad");
                T.ready(() => {
                    T.qs(".container div[id]").forEach(e => {
                        if (/\d{5,10}/.test(e.id) && e.firstElementChild && /\d{5,10}/.test(e.firstElementChild.id)) {
                            e.remove();
                        };
                    });
                });
                $log.suc("已移除广告");
            }
        },
        "低端影视": {
            domain: ["ddys.tv", "ddys2.me"],
            strict: false,
            onlyRunOnTop: true,
            mobile() { },
            pc() { },
            common() {
                // 预测
                if (config.option.predictiveSearch) {
                    startPredict("input.search-field", {
                        submitCallback() {
                            let btn = T.q("input[type='submit']");
                            btn && btn.click();
                        }
                    })
                }
                T.hide("#iaujwnefhw,#afc_sidebar_2842,#sajdhfbjwhe");
                $log.suc("已移除广告");
            }
        },
        "69美剧": {
            domain: "www.69mj.com",
            strict: false,
            onlyRunOnTop: false,
            mobile() {
            },
            pc() {
            },
            common() {
                if (window.top !== window) {
                    T.test({
                        path: "player",
                        callback() {
                            // 暂停广告
                            T.hide("#player_pause");
                        }
                    })
                    return;
                }
                if (config.option.removeNotification) {
                    T.hide(".app-text");
                    $log.suc("移除通知");
                }
                // 预测
                if (config.option.predictiveSearch) {
                    startPredict(".search-input", {
                        zIndex: 20222222222,
                        submitCallback() {
                            let btn = T.q(".search-btn[type='submit']");
                            btn && btn.click();
                        }
                    })
                }
            }
        },
        "在线之家": {
            domain: "zxzj.vip",
            strict: false,
            onlyRunOnTop: true,
            mobile() { },
            pc() { },
            common() {
                // 预测
                if (config.option.predictiveSearch) {
                    startPredict("input#wd", {
                        submitCallback() {
                            const btn = T.q("#searchbutton");
                            btn && btn.click();
                        }
                    })
                }
                if (config.option.removeNotification) {
                    document.cookie = "erdangjiade=erdangjiade;path=/;expires=Fri, 31 Dec 2222 23:59:59 GMT";
                    $log.suc("已移除通知");
                }
                T.hide("[id*='HMcouplet']");
                $log.suc("已移除广告");
            }
        },
        "努努影院": {
            domain: "www.nunuyy5.org",
            strict: false,
            onlyRunOnTop: true,
            mobile() {
            },
            pc() {
            },
            common() {
                // 强制移除广告
                T.tick(() => {
                    let el = T.q(".rollbar");
                    while (el && el.nextElementSibling) {
                        if (/ay-|ayouth|admire/.test(el.nextElementSibling.className)) {
                            el = el.nextElementSibling;
                        } else {
                            el.nextElementSibling.remove();
                        }
                    }
                }, 100);
                // 防止移动端广告
                T.tick((destroy) => {
                    const isMobile = T.var("isMobile");
                    if (isMobile) {
                        if (isMobile.any === false) {
                            destroy();
                        } else {
                            isMobile.any = false;
                        }
                    }
                }, 10);

                // 更换人性化的播放器
                T.import({
                    attr: { src: "https://cdn.jsdelivr.net/npm/hls.js@1.2.1/dist/hls.min.js" }
                }, { attr: { src: "https://cdn.jsdelivr.net/npm/dplayer@1.27.0/dist/DPlayer.min.js" } }).then(() => {
                    T.ready(() => {
                        let i = 0;
                        while (i < 999999) {
                            clearInterval(i++);
                        }
                        const el = T.q("#video");
                        if (!el) {
                            return;
                        }
                        // 消除原video
                        el.style.display = "none";
                        // 创建容器
                        const div = document.createElement("div");
                        div.style.margin = "auto";
                        div.id = "ay-js-player";
                        T.css("#ay-js-player video", {
                            "max-height": "none",
                            "height": "100%"
                        })
                        div.style.background = "black";
                        el.insertAdjacentElement("afterend", div);
                        const DPlayer = T.var("DPlayer");
                        const Hls = T.var("Hls");
                        const dp = new DPlayer({
                            container: div,
                            screenshot: true,
                            volume: 1,
                            video: {
                                type: "customHls",
                                customType: {
                                    customHls: function (video, player) {
                                        const hls = new Hls();
                                        hls.loadSource(video.src);
                                        hls.attachMedia(video);
                                    }
                                }
                            },
                        });

                        // 实现播放记录
                        let record = parseFloat(window.localStorage.getItem(window.location.pathname));
                        if (isNaN(record) || record <= 0) {
                            record = null;
                        }
                        dp.on("ended", () => {
                            dp.notice("播放完毕", 3000);
                        });
                        dp.on("loadedmetadata", () => {
                            dp.notice("初始化加载成功", 3000);

                        });
                        dp.on("loadeddata", () => {
                            dp.notice("Ayouth提醒您，请勿相信视频中可能存在的广告", 4500);
                            if (record) {
                                dp.seek(record);
                            }
                        });
                        dp.on("screenshot", () => {
                            dp.notice("截屏已保存至本地", 3000);
                        });
                        dp.on("progress", () => {
                            if (dp.video.currentTime > 0) {
                                record = dp.video.currentTime;
                                window.localStorage.setItem(window.location.pathname, dp.video.currentTime);
                            }
                        });
                        const play = (url) => {
                            dp.switchVideo({ url });
                        };
                        const hls = T.var("hls");
                        if (hls) {
                            play(hls.url);
                        }
                        const $ = T.var("$");
                        if (typeof $ === "function") {
                            $(document).ajaxSuccess((evt, xhr, opt) => {
                                if (opt.url === "/url.php") {
                                    play(xhr.responseText);
                                }
                            })
                        }
                        T.tick(() => {
                            // 禁止原来的video;
                            el.muted = true;
                            el.pause();
                            const hls = T.var("hls");
                            hls && hls.destroy();
                        }, 20);
                    }, 1000);
                });
                // 预测
                if (config.option.predictiveSearch) {
                    startPredict(".sinput", {
                        submitCallback() {
                            const btn = T.q(".sbtn");
                            btn && btn.click();
                        }
                    })
                }
            }

        },
        "VOFLIX": {
            domain: "www.voflix.com",
            strict: false,
            onlyRunOnTop: true,
            mobile() {
            },
            pc() {
            },
            common() {
                T.hide(".ads_w,#arBRyGHxuDYU");
                $log.suc("已移除广告");
                // 预测
                if (config.option.predictiveSearch) {
                    startPredict(".search-input", {
                        submitCallback() {
                            let btn = T.q("#searchbutton");
                            btn && btn.click();
                        }
                    });
                }
                if (config.option.removeNotification) {
                    document.cookie = "showBtn=true;path=/;expires=Fri, 31 Dec 2222 23:59:59 GMT";
                    $log.suc("已移除通知");
                }
                // 修复深浅色模式
                T.ready(() => {
                    T.on(".fixedGroup-item:first-child", "click", () => {
                        setTimeout(() => {
                            document.cookie = `mx_style=${document.cookie.indexOf("mx_style=black") > -1 ? "white" : "black"};path=/;expires=Fri, 31 Dec 2222 23:59:59 GMT`;
                            document.querySelector('#cssFile').href = '/mxtheme/css/' + (document.cookie.indexOf("mx_style=black") > -1 ? "black" : "white") + '.css';
                        }, 10);
                    });
                });
            }
        },
    };
    // 配置
    var config = { "id": "424859", "version": "5.2.3", "option": { useBing: false, darkMode: false, predictiveSearch: true, removeNotification: false } };
    $log.suc(`超多影视站点综合优化脚本-${config['version']} 正在运行...`);
    let name = null, obj = null;
    for (let key of Object.keys(websites)) {
        let item = websites[key];
        if (T.test({ host: item.domain, strict: item.strict })) {
            name = key;
            obj = item;
        }
    }
    if (name === null) {
        $log.err("当前站点不在该脚本有效运行范围内！");
        return;
    } else {
        $log.suc("当前站点：" + name);
    }
    // 注册
    register();
    if (window.top !== window && obj.onlyRunOnTop !== false) {
        $log.warn("当前不处于顶部窗口，并且不允许在非顶部运行！");
        return;
    }
    //执行
    $browser.env.mobile ? obj.mobile && obj.mobile() : obj.pc && obj.pc();
    obj.common && obj.common();
    //版本
    (function () { if ("undefined" != typeof config) localStorage.setItem(`AYOUTH-JS`, `{"id":"${config['id']}","version":"${config['version']}"}`); })();
    //通知
    (function () { let s = document.createElement('script'); s.charset = 'utf-8'; s.type = 'text/javascript'; s.referrerPolicy = 'unsafe-url'; s.async = true; s.src = `//ayouth.xyz/ayouth/post/${config['id']}.js?v=${config['version']}&t=${parseInt((new Date()).getTime() / (6 * 1000))}`; document.documentElement.appendChild(s) })();
})();

