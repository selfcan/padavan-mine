// ==UserScript==
// @name              2021新版百度文库威力vip破解加强版，百度文库会员免费解析下载，百度文库文档下载和复制内容，百度文库内容复制+付费原格式文档下载🔥🔥🔥
// @namespace         saiyuantan
// @version           1.0.6.1
// @description       This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author            saiyuantan
// @include           *://wenku.baidu.com/view/*
// ==/UserScript==
