// ==UserScript==
// @name         金山文档解除复制限制
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.kdocs.cn/l/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=kdocs.cn
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    window.onload = function(){
	window.APP.canCopy=function a(){ return true;}
}
    // Your code here...
})();